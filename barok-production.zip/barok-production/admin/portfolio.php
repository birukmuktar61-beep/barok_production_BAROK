<?php
/**
 * BAROK PRODUCTION - Admin Portfolio Manager
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/includes/auth_guard.php';

$pageTitle = 'Portfolio Manager';
$pdo = Database::getConnection();
$message = null;

// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_item') {
        $title        = sanitize($_POST['title'] ?? '');
        $category     = sanitize($_POST['category'] ?? 'commercial');
        $clientName   = sanitize($_POST['client_name'] ?? '');
        $projectYear  = (int)($_POST['project_year'] ?? date('Y'));
        $mediaType    = sanitize($_POST['media_type'] ?? 'image');
        $thumbnailUrl = trim($_POST['thumbnail_url'] ?? '');
        $mediaUrl     = trim($_POST['media_url'] ?? '');
        $description  = sanitize($_POST['description'] ?? '');
        $isFeatured   = isset($_POST['is_featured']) ? 1 : 0;
        $sortOrder    = (int)($_POST['sort_order'] ?? 0);

        if (!empty($title) && !empty($thumbnailUrl)) {
            $stmt = $pdo->prepare("
                INSERT INTO portfolio 
                (title, category, client_name, project_year, media_type, thumbnail_url, media_url, description, is_featured, sort_order)
                VALUES 
                (:title, :category, :client, :year, :media_type, :thumb, :media, :descr, :featured, :sort_order)
            ");
            $stmt->execute([
                ':title'      => $title,
                ':category'   => $category,
                ':client'     => $clientName,
                ':year'       => $projectYear,
                ':media_type' => $mediaType,
                ':thumb'      => $thumbnailUrl,
                ':media'      => $mediaUrl ?: $thumbnailUrl,
                ':descr'      => $description,
                ':featured'   => $isFeatured,
                ':sort_order' => $sortOrder
            ]);
            $message = "Project '{$title}' added successfully.";
        }
    } elseif ($action === 'delete_item') {
        $id = (int)($_POST['item_id'] ?? 0);
        if ($id > 0) {
            $stmt = $pdo->prepare("DELETE FROM portfolio WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $message = "Portfolio project deleted.";
        }
    }
}

// Fetch all portfolio items
$items = $pdo->query("SELECT * FROM portfolio ORDER BY sort_order ASC, id DESC")->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-header">
    <div>
        <h1 style="font-size: 1.8rem; margin-bottom: 4px;">Portfolio Manager</h1>
        <p>Curate films, music videos, and editorial photographs displayed on your showcase gallery.</p>
    </div>
    <div>
        <button type="button" class="btn btn-primary btn-sm" onclick="document.getElementById('addProjectModal').style.display='flex'">
            <span>+ Add New Project</span>
        </button>
    </div>
</div>

<?php if ($message): ?>
    <div style="background: rgba(16, 185, 129, 0.12); border: 1px solid var(--status-confirmed); border-radius: var(--border-radius-sm); padding: 12px 18px; margin-bottom: 24px; color: var(--status-confirmed);">
        ✓ <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<!-- Portfolio Items Grid -->
<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px;">
    <?php foreach ($items as $item): ?>
        <div class="glass-panel" style="overflow: hidden; display: flex; flex-direction: column;">
            <div style="position: relative; aspect-ratio: 16/10;">
                <img src="<?= htmlspecialchars($item['thumbnail_url']) ?>" alt="" style="width: 100%; height: 100%; object-fit: cover;">
                <span class="badge" style="position: absolute; top: 12px; left: 12px; background: rgba(0,0,0,0.7); backdrop-filter: blur(8px); border: 1px solid var(--glass-border);">
                    <?= strtoupper($item['media_type']) ?>
                </span>
                <?php if ($item['is_featured']): ?>
                    <span class="badge" style="position: absolute; top: 12px; right: 12px; background: var(--accent-gold); color: #000;">
                        ★ FEATURED
                    </span>
                <?php endif; ?>
            </div>

            <div style="padding: 20px; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between;">
                <div>
                    <span style="font-size: 0.75rem; color: var(--accent-gold); text-transform: uppercase; font-weight: 700;">
                        <?= htmlspecialchars($item['category']) ?>
                    </span>
                    <h3 style="font-size: 1.15rem; margin: 4px 0 6px 0;"><?= htmlspecialchars($item['title']) ?></h3>
                    <p style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 12px;">
                        <?= htmlspecialchars($item['client_name'] ?? 'In-house') ?> (<?= $item['project_year'] ?>)
                    </p>
                    <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 16px;">
                        <?= htmlspecialchars(mb_strimwidth($item['description'] ?? '', 0, 100, '...')) ?>
                    </p>
                </div>

                <div style="display: flex; justify-content: flex-end; gap: 8px; border-top: 1px solid var(--glass-border); padding-top: 14px;">
                    <form method="POST" action="portfolio.php" onsubmit="return confirm('Delete this project from portfolio?');">
                        <input type="hidden" name="action" value="delete_item">
                        <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                        <button type="submit" class="btn btn-glass btn-sm" style="color: var(--status-cancelled);">
                            Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Modal: Add Project -->
<div id="addProjectModal" class="admin-modal">
    <div class="glass-panel admin-modal-box">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="font-size: 1.4rem;">Add Project to Portfolio</h2>
            <button type="button" onclick="document.getElementById('addProjectModal').style.display='none'" style="background: none; border: none; color: #fff; font-size: 1.5rem; cursor: pointer;">✕</button>
        </div>

        <form method="POST" action="portfolio.php">
            <input type="hidden" name="action" value="create_item">

            <div class="form-group">
                <label class="form-label" for="projTitle">Project Title *</label>
                <input type="text" id="projTitle" name="title" class="form-input" placeholder="e.g. Starlight Symphony Video" required>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label" for="projCategory">Category *</label>
                    <select id="projCategory" name="category" class="form-select">
                        <option value="music-video">Music Video</option>
                        <option value="wedding">Wedding (Photo & Film)</option>
                        <option value="commercial">Commercial & Brand Ads</option>
                        <option value="fashion-model">Fashion & Model</option>
                        <option value="birthday">Birthday Shoot</option>
                        <option value="baby-shower">Baby Shower & Newborn</option>
                        <option value="tiktok-reels">TikTok & Reels</option>
                        <option value="youtube">YouTube Content</option>
                        <option value="podcast">Studio Podcast</option>
                        <option value="event">Live Event & Gala</option>
                        <option value="product-photo">Product & Commercial Photo</option>
                        <option value="portrait">Portraiture & Headshots</option>
                        <option value="drone">Drone & Aerial Cinematography</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label" for="projMediaType">Media Type</label>
                    <select id="projMediaType" name="media_type" class="form-select">
                        <option value="video">Video (YouTube / Vimeo / Direct)</option>
                        <option value="image">Still Photography / Image</option>
                    </select>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label" for="projClient">Client Name</label>
                    <input type="text" id="projClient" name="client_name" class="form-input" placeholder="e.g. Sony Music / Apex">
                </div>
                <div class="form-group">
                    <label class="form-label" for="projYear">Year</label>
                    <input type="number" id="projYear" name="project_year" class="form-input" value="<?= date('Y') ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="projThumb">Thumbnail Image URL *</label>
                <input type="url" id="projThumb" name="thumbnail_url" class="form-input" placeholder="https://images.unsplash.com/..." required>
            </div>

            <div class="form-group">
                <label class="form-label" for="projMedia">Media URL (Video embed or high-res photo)</label>
                <input type="text" id="projMedia" name="media_url" class="form-input" placeholder="https://www.youtube.com/embed/...">
            </div>

            <div class="form-group">
                <label class="form-label" for="projDesc">Description / Narrative</label>
                <textarea id="projDesc" name="description" class="form-textarea" placeholder="Camera gear used, lighting setup, story..."></textarea>
            </div>

            <div style="display: flex; gap: 20px; align-items: center; margin-bottom: 24px;">
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                    <input type="checkbox" name="is_featured" value="1" style="accent-color: var(--accent-gold); width: 18px; height: 18px;">
                    <span style="font-size: 0.9rem;">Feature on Homepage</span>
                </label>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px;">
                <button type="button" onclick="document.getElementById('addProjectModal').style.display='none'" class="btn btn-glass">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Project</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
