<?php
/**
 * BAROK PRODUCTION - Admin Services & Packages Manager
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/includes/auth_guard.php';

$pageTitle = 'Services & Packages';
$pdo = Database::getConnection();
$message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_service') {
        $title       = sanitize($_POST['title'] ?? '');
        $category    = sanitize($_POST['category'] ?? 'Commercial');
        $serviceType = sanitize($_POST['service_type'] ?? 'photo');
        $price       = (float)($_POST['price'] ?? 0);
        $duration    = (int)($_POST['duration_hours'] ?? 4);
        $shortDesc   = sanitize($_POST['short_desc'] ?? '');
        $featuresText = $_POST['features'] ?? '';
        $isFeatured  = isset($_POST['is_featured']) ? 1 : 0;

        if (!in_array($serviceType, ['photo', 'video', 'both'], true)) {
            $serviceType = 'photo';
        }

        // Parse features into JSON array
        $featureLines = array_filter(array_map('trim', explode("\n", $featuresText)));
        $featuresJson = json_encode(array_values($featureLines), JSON_UNESCAPED_SLASHES);

        if (!empty($title) && $price > 0) {
            $stmt = $pdo->prepare("
                INSERT INTO services (title, service_type, category, price, duration_hours, short_desc, features, is_featured, is_active)
                VALUES (:title, :service_type, :category, :price, :duration, :short_desc, :features, :featured, 1)
            ");
            $stmt->execute([
                ':title'        => $title,
                ':service_type' => $serviceType,
                ':category'     => $category,
                ':price'        => $price,
                ':duration'     => $duration,
                ':short_desc'   => $shortDesc,
                ':features'     => $featuresJson,
                ':featured'     => $isFeatured
            ]);
            $message = "Service package '{$title}' created successfully.";
        }
    } elseif ($action === 'update_price') {
        $id    = (int)($_POST['service_id'] ?? 0);
        $price = (float)($_POST['price'] ?? 0);
        if ($id > 0 && $price > 0) {
            $stmt = $pdo->prepare("UPDATE services SET price = :price WHERE id = :id");
            $stmt->execute([':price' => $price, ':id' => $id]);
            $message = "Package pricing updated.";
        }
    } elseif ($action === 'toggle_active') {
        $id = (int)($_POST['service_id'] ?? 0);
        if ($id > 0) {
            $stmt = $pdo->prepare("UPDATE services SET is_active = NOT is_active WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $message = "Package visibility toggled.";
        }
    }
}

$services = $pdo->query("SELECT * FROM services ORDER BY service_type ASC, price ASC")->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-header">
    <div>
        <h1 style="font-size: 1.8rem; margin-bottom: 4px;">Services & Pricing Packages</h1>
        <p>Define production packages, hourly allocations, and pricing structures.</p>
    </div>
    <div>
        <button type="button" class="btn btn-primary btn-sm" onclick="document.getElementById('addServiceModal').style.display='flex'">
            <span>+ Create Package</span>
        </button>
    </div>
</div>

<?php if ($message): ?>
    <div style="background: rgba(16, 185, 129, 0.12); border: 1px solid var(--status-confirmed); border-radius: var(--border-radius-sm); padding: 12px 18px; margin-bottom: 24px; color: var(--status-confirmed);">
        ✓ <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<div class="glass-panel" style="padding: 24px;">
    <div class="table-responsive">
        <table class="glass-table">
            <thead>
                <tr>
                    <th>Package Title</th>
                    <th>Type</th>
                    <th>Category</th>
                    <th>Duration</th>
                    <th>Price (ETB)</th>
                    <th>Featured</th>
                    <th>Status</th>
                    <th style="text-align: right;">Quick Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($services as $s):
                    $typeColors = ['photo' => '#3b82f6', 'video' => '#8b5cf6', 'both' => '#f59e0b'];
                    $typeLabels = ['photo' => '📷 Photo', 'video' => '🎬 Video', 'both' => '📷🎬 Combo'];
                    $svcType = $s['service_type'] ?? 'photo';
                    $typeColor = $typeColors[$svcType] ?? '#888';
                    $typeLabel = $typeLabels[$svcType] ?? $svcType;
                ?>
                    <tr>
                        <td>
                            <strong><?= htmlspecialchars($s['title']) ?></strong>
                            <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: 4px;"><?= htmlspecialchars($s['short_desc']) ?></p>
                        </td>
                        <td>
                            <span style="background: <?= $typeColor ?>22; color: <?= $typeColor ?>; border: 1px solid <?= $typeColor ?>55; border-radius: 20px; padding: 3px 10px; font-size: 0.78rem; font-weight: 600; white-space: nowrap;">
                                <?= $typeLabel ?>
                            </span>
                        </td>
                        <td><?= htmlspecialchars($s['category']) ?></td>
                        <td><?= $s['duration_hours'] ?> Hours</td>
                        <td>
                            <form method="POST" action="services.php" style="display: flex; gap: 6px; align-items: center;">
                                <input type="hidden" name="action" value="update_price">
                                <input type="hidden" name="service_id" value="<?= $s['id'] ?>">
                                <span style="color: var(--accent-gold); font-weight: 700; font-size: 0.82rem;">ETB</span>
                                <input type="number" name="price" step="100" value="<?= (int)$s['price'] ?>" class="form-input" style="width: 110px; padding: 6px 10px; font-size: 0.88rem;">
                                <button type="submit" class="btn btn-glass btn-sm" style="padding: 6px 10px;">Save</button>
                            </form>
                        </td>
                        <td>
                            <?= $s['is_featured'] ? '<span style="color: var(--accent-gold); font-weight: 700;">★ Yes</span>' : '<span style="color: var(--text-muted);">No</span>' ?>
                        </td>
                        <td>
                            <form method="POST" action="services.php">
                                <input type="hidden" name="action" value="toggle_active">
                                <input type="hidden" name="service_id" value="<?= $s['id'] ?>">
                                <button type="submit" class="btn btn-sm <?= $s['is_active'] ? 'btn-primary' : 'btn-glass' ?>" style="padding: 4px 10px; font-size: 0.75rem;">
                                    <?= $s['is_active'] ? 'Active' : 'Disabled' ?>
                                </button>
                            </form>
                        </td>
                        <td style="text-align: right;">
                            <a href="../booking.php?package=<?= $s['id'] ?>" target="_blank" class="btn btn-glass btn-sm" style="padding: 4px 10px; font-size: 0.75rem;">
                                Test Booking ↗
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal: Create Package -->
<div id="addServiceModal" class="admin-modal">
    <div class="glass-panel admin-modal-box">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 style="font-size: 1.4rem;">Create Production Package</h2>
            <button type="button" onclick="document.getElementById('addServiceModal').style.display='none'" style="background: none; border: none; color: #fff; font-size: 1.5rem; cursor: pointer;">✕</button>
        </div>

        <form method="POST" action="services.php">
            <input type="hidden" name="action" value="create_service">

            <div class="form-group">
                <label class="form-label" for="svcTitle">Package Title *</label>
                <input type="text" id="svcTitle" name="title" class="form-input" placeholder="e.g. Documentary Film Production" required>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label" for="svcType">Service Type *</label>
                    <select id="svcType" name="service_type" class="form-select" required>
                        <option value="photo">📷 Photo</option>
                        <option value="video">🎬 Video</option>
                        <option value="both">📷🎬 Both (Combo)</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label" for="svcCat">Category *</label>
                    <input type="text" id="svcCat" name="category" class="form-input" placeholder="e.g. Wedding Photography" required>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label" for="svcPrice">Base Price (ETB) *</label>
                    <input type="number" id="svcPrice" name="price" step="500" class="form-input" placeholder="15000" required>
                </div>
                <div class="form-group">
                    <label class="form-label" for="svcDuration">Duration (Hours)</label>
                    <input type="number" id="svcDuration" name="duration_hours" class="form-input" value="4">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="svcShort">Short Catchline / Description</label>
                <input type="text" id="svcShort" name="short_desc" class="form-input" placeholder="Brief summary of what this tier delivers...">
            </div>

            <div class="form-group">
                <label class="form-label" for="svcFeatures">Features (One per line)</label>
                <textarea id="svcFeatures" name="features" class="form-textarea" placeholder="Sony FX6 Rig&#10;Color Grading included&#10;2 Rounds Revisions"></textarea>
            </div>

            <div style="margin-bottom: 24px;">
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                    <input type="checkbox" name="is_featured" value="1" style="accent-color: var(--accent-gold); width: 18px; height: 18px;">
                    <span style="font-size: 0.9rem;">Mark as 'Most Popular / Featured'</span>
                </label>
            </div>

            <div style="display: flex; justify-content: flex-end; gap: 12px;">
                <button type="button" onclick="document.getElementById('addServiceModal').style.display='none'" class="btn btn-glass">Cancel</button>
                <button type="submit" class="btn btn-primary">Create Package</button>
            </div>
        </form>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
