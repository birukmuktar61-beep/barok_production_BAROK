<?php
/**
 * BAROK PRODUCTION - Admin Login Portal
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

$error = null;

if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please enter both your email address and password.';
    } else {
        try {
            $pdo = Database::getConnection();
            $stmt = $pdo->prepare("SELECT id, name, email, password_hash, role FROM admins WHERE email = :email LIMIT 1");
            $stmt->execute([':email' => $email]);
            $admin = $stmt->fetch();

            if ($admin && password_verify($password, $admin['password_hash'])) {
                // Regenerate session ID for security
                session_regenerate_id(true);

                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_name'] = $admin['name'];
                $_SESSION['admin_email'] = $admin['email'];
                $_SESSION['admin_role'] = $admin['role'];

                // Update last login
                $up = $pdo->prepare("UPDATE admins SET last_login = NOW() WHERE id = :id");
                $up->execute([':id' => $admin['id']]);

                header('Location: index.php');
                exit;
            } else {
                $error = 'Invalid email or password.';
            }
        } catch (Throwable $e) {
            $error = 'Authentication service error. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login — <?= APP_NAME ?></title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- Core Glassmorphism & Dark Mode CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 20px;
        }
        .login-card {
            width: 100%;
            max-width: 440px;
            padding: 40px 34px;
        }
    </style>
</head>
<body>

    <div class="glass-panel login-card">
        <div style="text-align: center; margin-bottom: 28px;">
            <a href="../index.php" class="brand-logo" style="justify-content: center; margin-bottom: 12px; display: inline-flex;">
                <span class="logo-icon">B</span>
                <span>BAROK<span style="color: var(--accent-gold);">.</span></span>
            </a>
            <h2 style="font-size: 1.6rem; margin-bottom: 6px;">Studio Admin Portal</h2>
            <p style="font-size: 0.85rem; color: var(--text-secondary);">Authenticate to manage schedules, clients, and portfolio.</p>
        </div>

        <?php if ($error): ?>
            <div style="background: rgba(239, 68, 68, 0.12); border: 1px solid var(--status-cancelled); border-radius: var(--border-radius-sm); padding: 12px 16px; margin-bottom: 20px; color: var(--status-cancelled); font-size: 0.88rem;">
                ⚠️ <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label class="form-label" for="adminEmail">Email Address</label>
                <input type="email" id="adminEmail" name="email" class="form-input" value="<?= htmlspecialchars($_POST['email'] ?? 'admin@barokproduction.com') ?>" required autocomplete="username">
            </div>

            <div class="form-group">
                <label class="form-label" for="adminPassword">Password</label>
                <input type="password" id="adminPassword" name="password" class="form-input" placeholder="••••••••" required autocomplete="current-password">
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 14px; margin-top: 10px;">
                <span>Sign In to Console</span>
                <span>→</span>
            </button>
        </form>

        <div style="margin-top: 24px; padding-top: 18px; border-top: 1px solid var(--glass-border); font-size: 0.8rem; color: var(--text-muted); text-align: center;">
            <p style="margin-bottom: 6px;">Default Setup Credentials:</p>
            <code style="background: rgba(255, 255, 255, 0.06); padding: 4px 8px; border-radius: 4px; color: var(--accent-gold); display: inline-block;">
                admin@barokproduction.com / Admin@12345
            </code>
            <div style="margin-top: 16px;">
                <a href="../index.php" style="color: var(--text-secondary); text-decoration: underline;">← Back to Public Website</a>
            </div>
        </div>
    </div>

</body>
</html>
