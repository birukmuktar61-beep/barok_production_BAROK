<?php
/**
 * BAROK PRODUCTION - Admin Testimonials & Reviews Moderation Console
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/includes/auth_guard.php';

$pageTitle = 'Testimonials & Reviews Moderation';
$pdo = Database::getConnection();
$message = null;
$error = null;

// Handle moderation actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['testimonial_id'] ?? 0);

    if ($id > 0) {
        if ($action === 'approve') {
            $stmt = $pdo->prepare("UPDATE testimonials SET is_approved = 1 WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $message = "Testimonial #{$id} approved and is now live on the public website.";
        } elseif ($action === 'unapprove') {
            $stmt = $pdo->prepare("UPDATE testimonials SET is_approved = 0 WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $message = "Testimonial #{$id} moved back to pending moderation.";
        } elseif ($action === 'delete') {
            $stmt = $pdo->prepare("DELETE FROM testimonials WHERE id = :id");
            $stmt->execute([':id' => $id]);
            $message = "Testimonial #{$id} deleted successfully.";
        }
    }
}

// Filter
$tab = $_GET['tab'] ?? 'pending';
if (!in_array($tab, ['pending', 'approved', 'all'], true)) {
    $tab = 'pending';
}

// Metrics
$totalCount    = (int)$pdo->query("SELECT COUNT(*) FROM testimonials")->fetchColumn();
$pendingCount  = (int)$pdo->query("SELECT COUNT(*) FROM testimonials WHERE is_approved = 0")->fetchColumn();
$approvedCount = (int)$pdo->query("SELECT COUNT(*) FROM testimonials WHERE is_approved = 1")->fetchColumn();

// Fetch reviews according to tab
if ($tab === 'pending') {
    $stmt = $pdo->prepare("SELECT * FROM testimonials WHERE is_approved = 0 ORDER BY id DESC");
    $stmt->execute();
} elseif ($tab === 'approved') {
    $stmt = $pdo->prepare("SELECT * FROM testimonials WHERE is_approved = 1 ORDER BY id DESC");
    $stmt->execute();
} else {
    $stmt = $pdo->query("SELECT * FROM testimonials ORDER BY is_approved ASC, id DESC");
}
$reviews = $stmt->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-header">
    <div>
        <h1 style="font-size: 1.8rem; margin-bottom: 4px;">Client Testimonials Moderation</h1>
        <p>Review and moderate client submissions before publishing them live to the portfolio showcase.</p>
    </div>
    <div style="display: flex; gap: 10px;">
        <a href="../index.php#reviews" target="_blank" class="btn btn-glass btn-sm">
            <span>View Public Showcase ↗</span>
        </a>
    </div>
</div>

<?php if ($message): ?>
    <div style="background: rgba(16, 185, 129, 0.12); border: 1px solid var(--status-confirmed); border-radius: var(--border-radius-sm); padding: 12px 18px; margin-bottom: 24px; color: var(--status-confirmed);">
        ✓ <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<!-- KPI Metrics -->
<div class="metrics-row" style="margin-bottom: 24px;">
    <div class="glass-panel metric-card" style="border-color: <?= $pendingCount > 0 ? 'rgba(245, 158, 11, 0.6)' : 'var(--glass-border)' ?>;">
        <div style="color: var(--status-pending); font-size: 1.4rem;">⏳</div>
        <div class="metric-value" style="color: var(--status-pending);"><?= $pendingCount ?></div>
        <div class="metric-title">Pending Moderation</div>
    </div>

    <div class="glass-panel metric-card" style="border-color: rgba(16, 185, 129, 0.4);">
        <div style="color: var(--status-confirmed); font-size: 1.4rem;">✓</div>
        <div class="metric-value" style="color: var(--status-confirmed);"><?= $approvedCount ?></div>
        <div class="metric-title">Live on Website</div>
    </div>

    <div class="glass-panel metric-card">
        <div style="color: var(--accent-gold); font-size: 1.4rem;">💬</div>
        <div class="metric-value"><?= $totalCount ?></div>
        <div class="metric-title">Total Submissions</div>
    </div>
</div>

<!-- Tabs Bar -->
<div class="glass-panel" style="padding: 14px 20px; margin-bottom: 26px; display: flex; gap: 12px; align-items: center; justify-content: space-between; flex-wrap: wrap;">
    <div style="display: flex; gap: 10px;">
        <a href="testimonials.php?tab=pending" class="btn btn-sm <?= $tab === 'pending' ? 'btn-primary' : 'btn-glass' ?>">
            <span>Pending Review</span>
            <?php if ($pendingCount > 0): ?>
                <span style="background: rgba(0,0,0,0.3); padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; margin-left: 4px;"><?= $pendingCount ?></span>
            <?php endif; ?>
        </a>
        <a href="testimonials.php?tab=approved" class="btn btn-sm <?= $tab === 'approved' ? 'btn-primary' : 'btn-glass' ?>">
            <span>Approved (Live)</span>
            <span style="background: rgba(0,0,0,0.3); padding: 2px 8px; border-radius: 10px; font-size: 0.75rem; margin-left: 4px;"><?= $approvedCount ?></span>
        </a>
        <a href="testimonials.php?tab=all" class="btn btn-sm <?= $tab === 'all' ? 'btn-primary' : 'btn-glass' ?>">
            <span>All Reviews</span>
        </a>
    </div>

    <span style="font-size: 0.85rem; color: var(--text-muted);">
        <?= count($reviews) ?> review(s) in this view
    </span>
</div>

<!-- Reviews List -->
<?php if (empty($reviews)): ?>
    <div class="glass-panel" style="padding: 40px; text-align: center; color: var(--text-muted);">
        <div style="font-size: 2rem; margin-bottom: 10px;">🌟</div>
        <h3 style="font-size: 1.1rem; margin-bottom: 6px;">No testimonials found</h3>
        <p style="font-size: 0.85rem;">
            <?= $tab === 'pending' ? 'All reviews have been moderated! Great job.' : 'No reviews match this category.' ?>
        </p>
    </div>
<?php else: ?>
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 20px;">
        <?php foreach ($reviews as $rev): 
            $stars = str_repeat('★', (int)$rev['rating']) . str_repeat('☆', 5 - (int)$rev['rating']);
            $dateFormatted = formatDateDual(substr($rev['created_at'], 0, 10), 'en');
        ?>
            <div class="glass-panel" style="padding: 24px; display: flex; flex-direction: column; justify-content: space-between; border-color: <?= $rev['is_approved'] ? 'rgba(16, 185, 129, 0.3)' : 'rgba(245, 158, 11, 0.4)' ?>;">
                <div>
                    <!-- Header with Rating and Status -->
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
                        <span style="color: var(--accent-gold); font-size: 1.15rem; letter-spacing: 2px;"><?= $stars ?></span>
                        <span class="badge" style="background: <?= $rev['is_approved'] ? 'rgba(16, 185, 129, 0.15)' : 'rgba(245, 158, 11, 0.15)' ?>; color: <?= $rev['is_approved'] ? 'var(--status-confirmed)' : 'var(--status-pending)' ?>; border: 1px solid <?= $rev['is_approved'] ? 'rgba(16, 185, 129, 0.3)' : 'rgba(245, 158, 11, 0.3)' ?>; padding: 3px 8px; font-size: 0.75rem; border-radius: 12px;">
                            <?= $rev['is_approved'] ? '● Approved (Live)' : '⏳ Pending Moderation' ?>
                        </span>
                    </div>

                    <!-- Review Text -->
                    <p style="font-size: 0.95rem; font-style: italic; margin-bottom: 18px; color: var(--text-primary); line-height: 1.55;">
                        "<?= htmlspecialchars($rev['review_text']) ?>"
                    </p>

                    <!-- Author Info -->
                    <div style="border-top: 1px solid var(--glass-border); padding-top: 12px; margin-bottom: 18px;">
                        <h4 style="font-size: 1rem; color: var(--accent-gold);"><?= htmlspecialchars($rev['client_name']) ?></h4>
                        <?php if (!empty($rev['client_role'])): ?>
                            <span style="font-size: 0.82rem; color: var(--text-muted); display: block;"><?= htmlspecialchars($rev['client_role']) ?></span>
                        <?php endif; ?>
                        <?php if (!empty($rev['project_type'])): ?>
                            <span style="display: inline-block; background: rgba(255, 183, 3, 0.1); color: var(--accent-gold); border: 1px solid rgba(255, 183, 3, 0.2); border-radius: 12px; font-size: 0.72rem; padding: 2px 8px; margin-top: 6px;">
                                <?= htmlspecialchars($rev['project_type']) ?>
                            </span>
                        <?php endif; ?>
                        <span style="font-size: 0.75rem; color: var(--text-muted); display: block; margin-top: 6px;">
                            📅 <?= $dateFormatted ?>
                        </span>
                    </div>
                </div>

                <!-- Actions -->
                <div style="display: flex; gap: 8px; justify-content: flex-end; padding-top: 12px; border-top: 1px solid var(--glass-border);">
                    <?php if (!$rev['is_approved']): ?>
                        <form method="POST" action="testimonials.php" style="display: inline;">
                            <input type="hidden" name="action" value="approve">
                            <input type="hidden" name="testimonial_id" value="<?= $rev['id'] ?>">
                            <button type="submit" class="btn btn-primary btn-sm" style="padding: 6px 14px; font-size: 0.8rem;">
                                <span>✓ Approve & Publish</span>
                            </button>
                        </form>
                    <?php else: ?>
                        <form method="POST" action="testimonials.php" style="display: inline;">
                            <input type="hidden" name="action" value="unapprove">
                            <input type="hidden" name="testimonial_id" value="<?= $rev['id'] ?>">
                            <button type="submit" class="btn btn-glass btn-sm" style="padding: 6px 12px; font-size: 0.8rem;" title="Remove from public view">
                                <span>Hide</span>
                            </button>
                        </form>
                    <?php endif; ?>

                    <form method="POST" action="testimonials.php" style="display: inline;" onsubmit="return confirm('Are you sure you want to permanently delete this testimonial?');">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="testimonial_id" value="<?= $rev['id'] ?>">
                        <button type="submit" class="btn btn-glass btn-sm" style="padding: 6px 10px; font-size: 0.8rem; color: var(--status-cancelled);" title="Delete permanently">
                            ✕
                        </button>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
