<?php
/**
 * BAROK PRODUCTION - Admin Header Template
 */

declare(strict_types=1);

$currentPage = basename($_SERVER['PHP_SELF']);
$adminName = $_SESSION['admin_name'] ?? 'Admin User';
$adminEmail = $_SESSION['admin_email'] ?? 'admin@barokproduction.com';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Admin Console' ?> — <?= APP_NAME ?></title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <!-- Admin & Core CSS -->
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="admin-layout">
        
        <!-- Sidebar Navigation -->
        <aside class="admin-sidebar">
            <a href="index.php" class="brand-logo" style="margin-bottom: 10px;">
                <span class="logo-icon">B</span>
                <span>BAROK<span style="color: var(--accent-gold);">.</span></span>
            </a>
            <span style="font-size: 0.72rem; text-transform: uppercase; letter-spacing: 1.5px; color: var(--accent-gold); font-weight: 700;">
                Studio Admin Console
            </span>

            <ul class="admin-nav">
                <li class="admin-nav-item <?= $currentPage === 'index.php' ? 'active' : '' ?>">
                    <a href="index.php">
                        <span>📊</span>
                        <span>Overview</span>
                    </a>
                </li>
                <li class="admin-nav-item <?= $currentPage === 'bookings.php' ? 'active' : '' ?>">
                    <a href="bookings.php">
                        <span>📅</span>
                        <span>Manage Bookings</span>
                    </a>
                </li>
                <li class="admin-nav-item <?= $currentPage === 'portfolio.php' ? 'active' : '' ?>">
                    <a href="portfolio.php">
                        <span>🎞️</span>
                        <span>Portfolio Manager</span>
                    </a>
                </li>
                <li class="admin-nav-item <?= $currentPage === 'services.php' ? 'active' : '' ?>">
                    <a href="services.php">
                        <span>💎</span>
                        <span>Services & Tiers</span>
                    </a>
                </li>
                <?php
                $pendingReviews = 0;
                try {
                    if (isset($pdo)) {
                        $pendingReviews = (int)$pdo->query("SELECT COUNT(*) FROM testimonials WHERE is_approved = 0")->fetchColumn();
                    }
                } catch (Throwable $e) {}
                ?>
                <li class="admin-nav-item <?= $currentPage === 'testimonials.php' ? 'active' : '' ?>">
                    <a href="testimonials.php" style="display: flex; align-items: center; justify-content: space-between;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span>💬</span>
                            <span>Testimonials</span>
                        </div>
                        <?php if ($pendingReviews > 0): ?>
                            <span style="background: var(--status-pending); color: #000; font-size: 0.72rem; font-weight: 800; padding: 2px 7px; border-radius: 10px;">
                                <?= $pendingReviews ?>
                            </span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="admin-nav-item <?= $currentPage === 'settings.php' ? 'active' : '' ?>">
                    <a href="settings.php">
                        <span>⚙️</span>
                        <span>Site Settings & Hero</span>
                    </a>
                </li>
                <li class="admin-nav-item">
                    <a href="../index.php" target="_blank">
                        <span>🌐</span>
                        <span>View Live Website ↗</span>
                    </a>
                </li>
            </ul>

            <div class="admin-user-profile">
                <div>
                    <strong style="font-size: 0.88rem; display: block;"><?= htmlspecialchars($adminName) ?></strong>
                    <span style="font-size: 0.75rem; color: var(--text-muted);"><?= htmlspecialchars($adminEmail) ?></span>
                </div>
                <a href="logout.php" title="Sign Out" style="color: var(--status-cancelled); font-size: 1.1rem; padding: 6px;">
                    ⏻
                </a>
            </div>
        </aside>

        <!-- Main Content Wrapper -->
        <main class="admin-main">
