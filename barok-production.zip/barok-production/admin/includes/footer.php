<?php
/**
 * BAROK PRODUCTION - Admin Footer Template
 */
?>
        </main>
    </div>

    <!-- Core Toast & Shared Helpers -->
    <script src="../assets/js/main.js"></script>
</body>
</html>
