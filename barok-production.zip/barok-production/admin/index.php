<?php
/**
 * BAROK PRODUCTION - Admin Dashboard Overview
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/includes/auth_guard.php';

$pageTitle = 'Dashboard Overview';
$pdo = Database::getConnection();

// Handle quick booking status update from dashboard
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $bookingId = (int)($_POST['booking_id'] ?? 0);
    $newStatus = sanitize($_POST['status'] ?? '');

    if ($bookingId > 0 && in_array($newStatus, ['pending', 'confirmed', 'completed', 'cancelled'])) {
        $update = $pdo->prepare("UPDATE bookings SET status = :status WHERE id = :id");
        $update->execute([':status' => $newStatus, ':id' => $bookingId]);
        header('Location: index.php?msg=status_updated');
        exit;
    }
}

// Compute KPIs
$totalBookings = (int)$pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$pendingBookings = (int)$pdo->query("SELECT COUNT(*) FROM bookings WHERE status = 'pending'")->fetchColumn();
$confirmedBookings = (int)$pdo->query("SELECT COUNT(*) FROM bookings WHERE status = 'confirmed'")->fetchColumn();
$pipelineRevenue = (float)$pdo->query("SELECT COALESCE(SUM(total_price), 0) FROM bookings WHERE status IN ('confirmed', 'completed')")->fetchColumn();
$pendingReviews = (int)$pdo->query("SELECT COUNT(*) FROM testimonials WHERE is_approved = 0")->fetchColumn();

// Fetch 6 most recent bookings
$recentStmt = $pdo->query("
    SELECT 
        b.id,
        b.reference_code,
        b.client_name,
        b.client_email,
        b.client_phone,
        b.booking_date,
        b.booking_time,
        b.shoot_location,
        b.total_price,
        b.status,
        b.created_at,
        s.title AS service_title
    FROM bookings b
    JOIN services s ON b.service_id = s.id
    ORDER BY b.id DESC
    LIMIT 6
");
$recentBookings = $recentStmt->fetchAll();

// Fetch recent inquiries
$inquiriesStmt = $pdo->query("SELECT * FROM inquiries ORDER BY id DESC LIMIT 5");
$inquiries = $inquiriesStmt->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-header">
    <div>
        <h1 style="font-size: 1.8rem; margin-bottom: 4px;">Studio Dashboard</h1>
        <p>Real-time telemetry, production schedules, and client reservations.</p>
    </div>
    <div style="display: flex; gap: 12px;">
        <a href="bookings.php" class="btn btn-primary btn-sm">
            <span>View All Bookings</span>
            <span>→</span>
        </a>
    </div>
</div>

<!-- KPI Metrics -->
<div class="metrics-row">
    <div class="glass-panel metric-card">
        <div style="color: var(--accent-gold); font-size: 1.4rem;">📅</div>
        <div class="metric-value gradient-text"><?= $totalBookings ?></div>
        <div class="metric-title">Total Bookings</div>
    </div>

    <div class="glass-panel metric-card" style="border-color: rgba(245, 158, 11, 0.4);">
        <div style="color: var(--status-pending); font-size: 1.4rem;">⏳</div>
        <div class="metric-value" style="color: var(--status-pending);"><?= $pendingBookings ?></div>
        <div class="metric-title">Pending Approvals</div>
    </div>

    <div class="glass-panel metric-card" style="border-color: rgba(16, 185, 129, 0.4);">
        <div style="color: var(--status-confirmed); font-size: 1.4rem;">🎬</div>
        <div class="metric-value" style="color: var(--status-confirmed);"><?= $confirmedBookings ?></div>
        <div class="metric-title">Confirmed Shoots</div>
    </div>

    <div class="glass-panel metric-card" style="border-color: rgba(0, 245, 212, 0.3);">
        <div style="color: var(--accent-cyan); font-size: 1.4rem;">💰</div>
        <div class="metric-value" style="color: var(--accent-cyan);"><?= formatPrice($pipelineRevenue) ?></div>
        <div class="metric-title">Confirmed Pipeline</div>
    </div>
</div>

<?php if (isset($pendingReviews) && $pendingReviews > 0): ?>
    <div class="glass-panel" style="background: rgba(245, 158, 11, 0.08); border: 1px solid var(--status-pending); border-radius: var(--border-radius-sm); padding: 16px 22px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px;">
        <div style="display: flex; align-items: center; gap: 14px;">
            <span style="font-size: 1.6rem; color: var(--status-pending);">⏳</span>
            <div>
                <strong style="font-size: 1rem; color: #fff;"><?= $pendingReviews ?> Client Testimonial(s) Awaiting Moderation</strong>
                <p style="font-size: 0.82rem; color: var(--text-muted); margin-top: 2px;">
                    Clients submitted reviews that will not be displayed publicly on the portfolio showcase until approved.
                </p>
            </div>
        </div>
        <a href="testimonials.php?tab=pending" class="btn btn-primary btn-sm">
            <span>Moderate Testimonials →</span>
        </a>
    </div>
<?php endif; ?>

<!-- Recent Bookings Table -->
<div class="glass-panel" style="padding: 24px; margin-bottom: 36px;">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2 style="font-size: 1.25rem;">Recent Production Bookings</h2>
        <a href="bookings.php" style="color: var(--accent-gold); font-size: 0.85rem; font-weight: 600;">Full Booking Archive →</a>
    </div>

    <div class="table-responsive">
        <table class="glass-table">
            <thead>
                <tr>
                    <th>Ref Code</th>
                    <th>Client / Artist</th>
                    <th>Package</th>
                    <th>Shoot Date</th>
                    <th>Fee</th>
                    <th>Status</th>
                    <th style="text-align: right;">Quick Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($recentBookings)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; color: var(--text-muted); padding: 30px;">
                            No bookings recorded yet. New submissions will appear here instantly.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($recentBookings as $b): ?>
                        <tr>
                            <td>
                                <strong style="font-family: var(--font-display); color: var(--accent-gold);">
                                    <?= htmlspecialchars($b['reference_code']) ?>
                                </strong>
                            </td>
                            <td>
                                <div><strong><?= htmlspecialchars($b['client_name']) ?></strong></div>
                                <span style="font-size: 0.78rem; color: var(--text-muted);"><?= htmlspecialchars($b['client_phone']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($b['service_title']) ?></td>
                            <td>
                                <div><strong><?= formatDateDual($b['booking_date'], 'en') ?></strong></div>
                                <span style="font-size: 0.78rem; color: var(--text-muted);"><?= htmlspecialchars($b['booking_time']) ?></span>
                            </td>
                            <td><strong><?= formatPrice((float)$b['total_price']) ?></strong></td>
                            <td>
                                <span class="badge badge-<?= htmlspecialchars($b['status']) ?>">
                                    ● <?= ucfirst($b['status']) ?>
                                </span>
                            </td>
                            <td style="text-align: right;">
                                <form method="POST" action="index.php" style="display: inline-flex; gap: 6px;">
                                    <input type="hidden" name="action" value="update_status">
                                    <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                                    <?php if ($b['status'] === 'pending'): ?>
                                        <button type="submit" name="status" value="confirmed" class="btn btn-primary btn-sm" style="padding: 4px 10px; font-size: 0.75rem;" title="Approve & Confirm">
                                            Confirm
                                        </button>
                                    <?php elseif ($b['status'] === 'confirmed'): ?>
                                        <button type="submit" name="status" value="completed" class="btn btn-glass btn-sm" style="padding: 4px 10px; font-size: 0.75rem;" title="Mark as Completed">
                                            Complete
                                        </button>
                                    <?php endif; ?>
                                    <a href="bookings.php?id=<?= $b['id'] ?>" class="btn btn-glass btn-sm" style="padding: 4px 10px; font-size: 0.75rem;">
                                        Details
                                    </a>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Inquiries Section -->
<div class="glass-panel" style="padding: 24px;">
    <h2 style="font-size: 1.25rem; margin-bottom: 18px;">Recent Inquiries & Contact Messages</h2>

    <?php if (empty($inquiries)): ?>
        <p style="color: var(--text-muted); font-size: 0.9rem;">No contact messages received yet.</p>
    <?php else: ?>
        <div style="display: flex; flex-direction: column; gap: 14px;">
            <?php foreach ($inquiries as $inq): ?>
                <div style="background: rgba(255, 255, 255, 0.02); border: 1px solid var(--glass-border); border-radius: var(--border-radius-sm); padding: 16px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                        <div>
                            <strong><?= htmlspecialchars($inq['name']) ?></strong>
                            <span style="font-size: 0.82rem; color: var(--text-muted); margin-left: 8px;">&lt;<?= htmlspecialchars($inq['email']) ?>&gt;</span>
                        </div>
                        <span style="font-size: 0.78rem; color: var(--text-muted);"><?= $inq['created_at'] ?></span>
                    </div>
                    <div style="font-size: 0.9rem; font-weight: 600; color: var(--accent-gold); margin-bottom: 4px;">
                        <?= htmlspecialchars($inq['subject']) ?>
                    </div>
                    <p style="font-size: 0.88rem; color: var(--text-secondary); margin: 0;">
                        <?= nl2br(htmlspecialchars($inq['message'])) ?>
                    </p>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
