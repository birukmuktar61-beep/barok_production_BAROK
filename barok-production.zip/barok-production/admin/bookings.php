<?php
/**
 * BAROK PRODUCTION - Admin Booking Management
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/includes/auth_guard.php';

$pageTitle = 'Manage Bookings';
$pdo = Database::getConnection();
$message = null;

// Handle Status & Admin Notes Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_booking') {
        $bookingId  = (int)($_POST['booking_id'] ?? 0);
        $newStatus  = sanitize($_POST['status'] ?? 'pending');
        $adminNotes = sanitize($_POST['admin_notes'] ?? '');

        if ($bookingId > 0 && in_array($newStatus, ['pending', 'confirmed', 'completed', 'cancelled'])) {
            $stmt = $pdo->prepare("UPDATE bookings SET status = :status, admin_notes = :notes WHERE id = :id");
            $stmt->execute([
                ':status' => $newStatus,
                ':notes'  => $adminNotes,
                ':id'     => $bookingId
            ]);
            $message = "Booking #{$bookingId} updated successfully.";
        }
    } elseif ($action === 'delete_booking') {
        $bookingId = (int)($_POST['booking_id'] ?? 0);
        if ($bookingId > 0) {
            $stmt = $pdo->prepare("DELETE FROM bookings WHERE id = :id");
            $stmt->execute([':id' => $bookingId]);
            $message = "Booking #{$bookingId} removed.";
        }
    }
}

// Filtering & Search
$statusFilter = sanitize($_GET['status'] ?? 'all');
$searchQuery  = sanitize($_GET['search'] ?? '');

$sql = "
    SELECT 
        b.*,
        s.title AS service_title,
        s.category AS service_category
    FROM bookings b
    JOIN services s ON b.service_id = s.id
    WHERE 1=1
";
$params = [];

if ($statusFilter !== 'all' && in_array($statusFilter, ['pending', 'confirmed', 'completed', 'cancelled'])) {
    $sql .= " AND b.status = :status";
    $params[':status'] = $statusFilter;
}

if (!empty($searchQuery)) {
    $sql .= " AND (b.reference_code LIKE :q OR b.client_name LIKE :q OR b.client_email LIKE :q)";
    $params[':q'] = "%{$searchQuery}%";
}

$sql .= " ORDER BY b.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$bookings = $stmt->fetchAll();

// Check if viewing a specific booking detail
$activeBookingId = (int)($_GET['id'] ?? 0);
$activeBooking = null;
if ($activeBookingId > 0) {
    foreach ($bookings as $b) {
        if ((int)$b['id'] === $activeBookingId) {
            $activeBooking = $b;
            break;
        }
    }
    if (!$activeBooking) {
        // Query directly if filtered out
        $detailStmt = $pdo->prepare("
            SELECT b.*, s.title AS service_title, s.category AS service_category
            FROM bookings b
            JOIN services s ON b.service_id = s.id
            WHERE b.id = :id
        ");
        $detailStmt->execute([':id' => $activeBookingId]);
        $activeBooking = $detailStmt->fetch();
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-header">
    <div>
        <h1 style="font-size: 1.8rem; margin-bottom: 4px;">Production Bookings</h1>
        <p>Review incoming reservations, allocate schedule slots, and confirm shoot logistics.</p>
    </div>
</div>

<?php if ($message): ?>
    <div style="background: rgba(16, 185, 129, 0.12); border: 1px solid var(--status-confirmed); border-radius: var(--border-radius-sm); padding: 12px 18px; margin-bottom: 24px; color: var(--status-confirmed);">
        ✓ <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<!-- Filter & Search Bar -->
<div class="glass-panel" style="padding: 18px 24px; margin-bottom: 26px;">
    <form method="GET" action="bookings.php" style="display: flex; gap: 14px; flex-wrap: wrap; align-items: center; justify-content: space-between;">
        <div style="display: flex; gap: 10px; align-items: center; flex-wrap: wrap;">
            <a href="bookings.php?status=all" class="btn btn-sm <?= $statusFilter === 'all' ? 'btn-primary' : 'btn-glass' ?>">All</a>
            <a href="bookings.php?status=pending" class="btn btn-sm <?= $statusFilter === 'pending' ? 'btn-primary' : 'btn-glass' ?>">Pending</a>
            <a href="bookings.php?status=confirmed" class="btn btn-sm <?= $statusFilter === 'confirmed' ? 'btn-primary' : 'btn-glass' ?>">Confirmed</a>
            <a href="bookings.php?status=completed" class="btn btn-sm <?= $statusFilter === 'completed' ? 'btn-primary' : 'btn-glass' ?>">Completed</a>
            <a href="bookings.php?status=cancelled" class="btn btn-sm <?= $statusFilter === 'cancelled' ? 'btn-primary' : 'btn-glass' ?>">Cancelled</a>
        </div>

        <div style="display: flex; gap: 8px;">
            <input type="text" name="search" value="<?= htmlspecialchars($searchQuery) ?>" placeholder="Search ref, name, email..." class="form-input" style="padding: 8px 14px; font-size: 0.88rem; width: 220px;">
            <button type="submit" class="btn btn-glass btn-sm">Filter</button>
            <?php if (!empty($searchQuery) || $statusFilter !== 'all'): ?>
                <a href="bookings.php" class="btn btn-glass btn-sm">Clear</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- Active Booking Detail Modal/Drawer if selected -->
<?php if ($activeBooking): 
    $addons = json_decode($activeBooking['add_ons'] ?? '[]', true) ?: [];
?>
    <div class="glass-panel" style="padding: 30px; margin-bottom: 30px; border-color: var(--accent-gold); background: rgba(255, 183, 3, 0.04);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <div>
                <span style="font-size: 0.78rem; text-transform: uppercase; color: var(--text-muted); letter-spacing: 1px;">Selected Booking Inspection</span>
                <h2 style="font-size: 1.5rem; color: var(--accent-gold);">
                    Ref: <?= htmlspecialchars($activeBooking['reference_code']) ?>
                </h2>
            </div>
            <a href="bookings.php" class="btn btn-glass btn-sm">✕ Close Inspector</a>
        </div>

        <form method="POST" action="bookings.php">
            <input type="hidden" name="action" value="update_booking">
            <input type="hidden" name="booking_id" value="<?= $activeBooking['id'] ?>">

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 20px;">
                <div>
                    <span style="color: var(--text-muted); font-size: 0.8rem;">Client Name:</span>
                    <strong style="display: block; font-size: 1rem;"><?= htmlspecialchars($activeBooking['client_name']) ?></strong>
                </div>
                <div>
                    <span style="color: var(--text-muted); font-size: 0.8rem;">Client Email:</span>
                    <strong style="display: block; font-size: 1rem;"><?= htmlspecialchars($activeBooking['client_email']) ?></strong>
                </div>
                <div>
                    <span style="color: var(--text-muted); font-size: 0.8rem;">Client Phone:</span>
                    <strong style="display: block; font-size: 1rem;"><?= htmlspecialchars($activeBooking['client_phone']) ?></strong>
                </div>
                <div>
                    <span style="color: var(--text-muted); font-size: 0.8rem;">Package:</span>
                    <strong style="display: block; font-size: 1rem; color: var(--accent-gold);"><?= htmlspecialchars($activeBooking['service_title']) ?></strong>
                </div>
                <div>
                    <span style="color: var(--text-muted); font-size: 0.8rem;">Shoot Date & Time:</span>
                    <strong style="display: block; font-size: 1rem;"><?= formatDateDual($activeBooking['booking_date'], 'en') ?> (<?= htmlspecialchars($activeBooking['booking_time']) ?>)</strong>
                </div>
                <div>
                    <span style="color: var(--text-muted); font-size: 0.8rem;">Total Quoted Price:</span>
                    <strong style="display: block; font-size: 1.2rem; color: var(--accent-gold);"><?= formatPrice((float)$activeBooking['total_price']) ?></strong>
                </div>
            </div>

            <div style="margin-bottom: 20px;">
                <span style="color: var(--text-muted); font-size: 0.8rem; display: block; margin-bottom: 4px;">Shoot Location:</span>
                <div style="background: rgba(0,0,0,0.3); padding: 10px 14px; border-radius: var(--border-radius-sm); border: 1px solid var(--glass-border);">
                    📍 <?= htmlspecialchars($activeBooking['shoot_location']) ?>
                </div>
            </div>

            <?php if (!empty($activeBooking['project_notes'])): ?>
                <div style="margin-bottom: 20px;">
                    <span style="color: var(--text-muted); font-size: 0.8rem; display: block; margin-bottom: 4px;">Client Brief & Notes:</span>
                    <div style="background: rgba(0,0,0,0.3); padding: 10px 14px; border-radius: var(--border-radius-sm); border: 1px solid var(--glass-border); font-size: 0.9rem;">
                        <?= nl2br(htmlspecialchars($activeBooking['project_notes'])) ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($addons)): ?>
                <div style="margin-bottom: 20px;">
                    <span style="color: var(--text-muted); font-size: 0.8rem; display: block; margin-bottom: 4px;">Add-on Extras:</span>
                    <ul style="list-style: none; padding-left: 0;">
                        <?php foreach ($addons as $addon): ?>
                            <li style="font-size: 0.9rem; color: var(--accent-gold);">
                                + <?= htmlspecialchars($addon['title'] ?? '') ?> (<?= formatPrice((float)($addon['price'] ?? 0)) ?>)
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px; margin-top: 24px; border-top: 1px solid var(--glass-border); padding-top: 20px;">
                <div class="form-group">
                    <label class="form-label" for="bookingStatusSelect">Update Booking Status</label>
                    <select id="bookingStatusSelect" name="status" class="form-select">
                        <option value="pending" <?= $activeBooking['status'] === 'pending' ? 'selected' : '' ?>>Pending Review</option>
                        <option value="confirmed" <?= $activeBooking['status'] === 'confirmed' ? 'selected' : '' ?>>Confirmed</option>
                        <option value="completed" <?= $activeBooking['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
                        <option value="cancelled" <?= $activeBooking['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="adminNotesInput">Studio Production Notes (Visible to client on status portal)</label>
                    <input type="text" id="adminNotesInput" name="admin_notes" class="form-input" value="<?= htmlspecialchars($activeBooking['admin_notes'] ?? '') ?>" placeholder="e.g. Call sheet sent to client email. Crew call at 08:30 AM.">
                </div>
            </div>

            <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 10px;">
                <button type="submit" class="btn btn-primary">
                    <span>Save Changes & Sync</span>
                    <span>✓</span>
                </button>
            </div>
        </form>
    </div>
<?php endif; ?>

<!-- Bookings Table -->
<div class="glass-panel" style="padding: 24px;">
    <div class="table-responsive">
        <table class="glass-table">
            <thead>
                <tr>
                    <th>Ref</th>
                    <th>Client</th>
                    <th>Package</th>
                    <th>Date & Time</th>
                    <th>Location</th>
                    <th>Fee</th>
                    <th>Status</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($bookings)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; color: var(--text-muted); padding: 40px;">
                            No bookings match your current criteria.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($bookings as $b): ?>
                        <tr>
                            <td>
                                <strong style="font-family: var(--font-display); color: var(--accent-gold);">
                                    <?= htmlspecialchars($b['reference_code']) ?>
                                </strong>
                            </td>
                            <td>
                                <div><strong><?= htmlspecialchars($b['client_name']) ?></strong></div>
                                <span style="font-size: 0.78rem; color: var(--text-muted);"><?= htmlspecialchars($b['client_email']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($b['service_title']) ?></td>
                            <td>
                                <div><strong><?= formatDateDual($b['booking_date'], 'en') ?></strong></div>
                                <span style="font-size: 0.78rem; color: var(--text-muted);"><?= htmlspecialchars($b['booking_time']) ?></span>
                            </td>
                            <td style="max-width: 160px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?= htmlspecialchars($b['shoot_location']) ?>">
                                <?= htmlspecialchars($b['shoot_location']) ?>
                            </td>
                            <td><strong><?= formatPrice((float)$b['total_price']) ?></strong></td>
                            <td>
                                <span class="badge badge-<?= htmlspecialchars($b['status']) ?>">
                                    ● <?= ucfirst($b['status']) ?>
                                </span>
                            </td>
                            <td style="text-align: right; white-space: nowrap;">
                                <a href="bookings.php?id=<?= $b['id'] ?>" class="btn btn-primary btn-sm" style="padding: 4px 10px; font-size: 0.75rem;">
                                    Inspect / Edit
                                </a>
                                <form method="POST" action="bookings.php" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this booking record?');">
                                    <input type="hidden" name="action" value="delete_booking">
                                    <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                                    <button type="submit" class="btn btn-glass btn-sm" style="padding: 4px 8px; font-size: 0.75rem; color: var(--status-cancelled);">
                                        ✕
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
