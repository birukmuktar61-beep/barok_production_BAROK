<?php
/**
 * BAROK PRODUCTION - Admin Site Settings & Hero Media Manager
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/includes/auth_guard.php';

$pageTitle = 'Site Settings & Metrics';
$pdo = Database::getConnection();
$message = null;
$error = null;

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'update_settings') {
        $allowedKeys = [
            'hero_video_url'   => 'hero',
            'hero_bg_image'    => 'hero',
            'stat_shoots_num'  => 'metrics',
            'stat_rating_num'  => 'metrics',
            'stat_awards_num'  => 'metrics',
            'stat_hdr_num'     => 'metrics',
            'app_phone'        => 'contact',
            'app_phone_raw'    => 'contact',
            'social_telegram'  => 'social',
            'social_instagram' => 'social',
            'social_tiktok'    => 'social',
            'social_youtube'   => 'social',
            'social_facebook'  => 'social'
        ];

        try {
            $pdo->beginTransaction();

            $updateStmt = $pdo->prepare("
                INSERT INTO settings (setting_key, setting_value, setting_group)
                VALUES (:key, :val, :grp)
                ON DUPLICATE KEY UPDATE 
                    setting_value = VALUES(setting_value),
                    updated_at = CURRENT_TIMESTAMP
            ");

            foreach ($allowedKeys as $key => $group) {
                if (isset($_POST[$key])) {
                    $val = trim((string)$_POST[$key]);
                    $updateStmt->execute([
                        ':key' => $key,
                        ':val' => $val,
                        ':grp' => $group
                    ]);
                }
            }

            $pdo->commit();
            // Clear in-memory cache
            $GLOBALS['_BAROK_SETTINGS_CACHE'] = null;
            $message = "Settings and metrics successfully updated!";
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = "Failed to update settings: " . $e->getMessage();
        }
    }
}

// Fetch current settings
$currentSettings = getAllSettings($pdo);

require_once __DIR__ . '/includes/header.php';
?>

<div class="admin-content">
    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 28px;">
        <div>
            <h1 style="font-size: 1.8rem; font-weight: 700; color: #fff; margin-bottom: 6px;">
                ⚙️ Website Settings & Hero Media
            </h1>
            <p style="color: var(--text-muted); font-size: 0.92rem;">
                Control the hero video showreel, background media, and live home page performance metrics dynamically.
            </p>
        </div>
        <div>
            <a href="../index.php" target="_blank" class="btn btn-glass btn-sm" style="display: inline-flex; align-items: center; gap: 8px;">
                <span>🌐 Preview Live Site</span>
            </a>
        </div>
    </div>

    <?php if ($message): ?>
        <div style="background: rgba(16, 185, 129, 0.15); border: 1px solid rgba(16, 185, 129, 0.4); color: #34d399; padding: 14px 20px; border-radius: var(--border-radius-md); margin-bottom: 24px; font-weight: 500;">
            ✓ <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.4); color: #f87171; padding: 14px 20px; border-radius: var(--border-radius-md); margin-bottom: 24px; font-weight: 500;">
            ⚠ <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="settings.php">
        <input type="hidden" name="action" value="update_settings">

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(440px, 1fr)); gap: 24px; margin-bottom: 28px;">
            
            <!-- Hero Video & Media Settings Panel -->
            <div class="glass-panel" style="padding: 28px 30px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 20px; padding-bottom: 14px; border-bottom: 1px solid var(--glass-border);">
                    <span style="font-size: 1.4rem;">🎬</span>
                    <div>
                        <h2 style="font-size: 1.15rem; font-weight: 600; color: #fff; margin: 0;">Hero Showreel & Media</h2>
                        <span style="font-size: 0.78rem; color: var(--accent-gold);">Controls the primary video reel on index.php</span>
                    </div>
                </div>

                <div class="form-group" style="margin-bottom: 20px;">
                    <label class="form-label" for="hero_video_url" style="display: flex; justify-content: space-between;">
                        <span>Hero Video URL (YouTube / Vimeo / MP4)</span>
                        <span style="font-size: 0.75rem; color: var(--text-muted);">Embed format supported</span>
                    </label>
                    <input 
                        type="url" 
                        id="hero_video_url" 
                        name="hero_video_url" 
                        class="form-input" 
                        value="<?= htmlspecialchars($currentSettings['hero_video_url'] ?? '') ?>" 
                        placeholder="https://www.youtube.com/embed/dQw4w9WgXcQ"
                        required
                    >
                    <small style="color: var(--text-muted); font-size: 0.78rem; display: block; margin-top: 6px;">
                        Tip: For YouTube, use embed links like <code>https://www.youtube.com/embed/VIDEO_ID</code> or standard share URLs.
                    </small>
                </div>

                <div class="form-group" style="margin-bottom: 20px;">
                    <label class="form-label" for="hero_bg_image">
                        <span>Hero Reel Poster / Rig Image URL</span>
                    </label>
                    <input 
                        type="url" 
                        id="hero_bg_image" 
                        name="hero_bg_image" 
                        class="form-input" 
                        value="<?= htmlspecialchars($currentSettings['hero_bg_image'] ?? '') ?>" 
                        placeholder="https://images.unsplash.com/..."
                        required
                    >
                    <small style="color: var(--text-muted); font-size: 0.78rem; display: block; margin-top: 6px;">
                        High-resolution camera rig or behind-the-scenes banner displayed as the video thumbnail poster.
                    </small>
                </div>

                <!-- Preview Thumbnail Card -->
                <div style="background: rgba(0,0,0,0.3); border-radius: var(--border-radius-md); padding: 14px; border: 1px solid rgba(255,255,255,0.06); margin-top: 14px;">
                    <span style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-muted); display: block; margin-bottom: 8px;">Poster Image Preview:</span>
                    <div style="height: 140px; border-radius: 8px; overflow: hidden; background: #000; position: relative;">
                        <img 
                            id="posterPreviewImg"
                            src="<?= htmlspecialchars($currentSettings['hero_bg_image'] ?? '') ?>" 
                            alt="Hero Poster Preview" 
                            style="width: 100%; height: 100%; object-fit: cover;"
                            onerror="this.src='https://images.unsplash.com/photo-1518135714426-c18f5ffb6f4d?auto=format&fit=crop&w=1600&q=80'"
                        >
                        <div style="position: absolute; inset: 0; background: rgba(0,0,0,0.35); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 1.5rem;">
                            ▶
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dynamic Performance Stats Counter Panel -->
            <div class="glass-panel" style="padding: 28px 30px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 20px; padding-bottom: 14px; border-bottom: 1px solid var(--glass-border);">
                    <span style="font-size: 1.4rem;">📈</span>
                    <div>
                        <h2 style="font-size: 1.15rem; font-weight: 600; color: #fff; margin: 0;">Dynamic Stats Counter</h2>
                        <span style="font-size: 0.78rem; color: var(--accent-gold);">Live metrics grid displayed under hero section</span>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    
                    <div class="form-group">
                        <label class="form-label" for="stat_shoots_num">
                            <span>Shoots Metric</span>
                        </label>
                        <input 
                            type="text" 
                            id="stat_shoots_num" 
                            name="stat_shoots_num" 
                            class="form-input" 
                            value="<?= htmlspecialchars($currentSettings['stat_shoots_num'] ?? '150+') ?>" 
                            placeholder="e.g. 150+ or 250+"
                            required
                        >
                        <small style="color: var(--text-muted); font-size: 0.75rem; display: block; margin-top: 4px;">
                            Label: Commercial & Music Shoots
                        </small>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="stat_rating_num">
                            <span>Approval Metric</span>
                        </label>
                        <input 
                            type="text" 
                            id="stat_rating_num" 
                            name="stat_rating_num" 
                            class="form-input" 
                            value="<?= htmlspecialchars($currentSettings['stat_rating_num'] ?? '99.8%') ?>" 
                            placeholder="e.g. 99.8% or 100%"
                            required
                        >
                        <small style="color: var(--text-muted); font-size: 0.75rem; display: block; margin-top: 4px;">
                            Label: Client Approval Rating
                        </small>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="stat_awards_num">
                            <span>Awards Metric</span>
                        </label>
                        <input 
                            type="text" 
                            id="stat_awards_num" 
                            name="stat_awards_num" 
                            class="form-input" 
                            value="<?= htmlspecialchars($currentSettings['stat_awards_num'] ?? '18') ?>" 
                            placeholder="e.g. 18 or 24"
                            required
                        >
                        <small style="color: var(--text-muted); font-size: 0.75rem; display: block; margin-top: 4px;">
                            Label: Festival & Industry Awards
                        </small>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="stat_hdr_num">
                            <span>Quality Standard Metric</span>
                        </label>
                        <input 
                            type="text" 
                            id="stat_hdr_num" 
                            name="stat_hdr_num" 
                            class="form-input" 
                            value="<?= htmlspecialchars($currentSettings['stat_hdr_num'] ?? '4K HDR') ?>" 
                            placeholder="e.g. 4K HDR or 8K RAW"
                            required
                        >
                        <small style="color: var(--text-muted); font-size: 0.75rem; display: block; margin-top: 4px;">
                            Label: Master Color Standard
                        </small>
                    </div>

                </div>

                <!-- Live Counter Preview Component -->
                <div style="background: rgba(0,0,0,0.3); border-radius: var(--border-radius-md); padding: 18px; border: 1px solid rgba(255,255,255,0.06); margin-top: 24px;">
                    <span style="font-size: 0.75rem; text-transform: uppercase; color: var(--text-muted); display: block; margin-bottom: 12px;">Live Counter Box Preview:</span>
                    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px;">
                        <div style="text-align: center; background: rgba(255,255,255,0.03); padding: 10px 4px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);">
                            <div id="previewShoots" style="color: var(--accent-gold); font-size: 1.1rem; font-weight: 700;"><?= htmlspecialchars($currentSettings['stat_shoots_num'] ?? '150+') ?></div>
                            <div style="font-size: 0.65rem; color: var(--text-muted);">Shoots</div>
                        </div>
                        <div style="text-align: center; background: rgba(255,255,255,0.03); padding: 10px 4px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);">
                            <div id="previewRating" style="color: var(--accent-gold); font-size: 1.1rem; font-weight: 700;"><?= htmlspecialchars($currentSettings['stat_rating_num'] ?? '99.8%') ?></div>
                            <div style="font-size: 0.65rem; color: var(--text-muted);">Rating</div>
                        </div>
                        <div style="text-align: center; background: rgba(255,255,255,0.03); padding: 10px 4px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);">
                            <div id="previewAwards" style="color: var(--accent-gold); font-size: 1.1rem; font-weight: 700;"><?= htmlspecialchars($currentSettings['stat_awards_num'] ?? '18') ?></div>
                            <div style="font-size: 0.65rem; color: var(--text-muted);">Awards</div>
                        </div>
                        <div style="text-align: center; background: rgba(255,255,255,0.03); padding: 10px 4px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05);">
                            <div id="previewHdr" style="color: var(--accent-gold); font-size: 1.1rem; font-weight: 700;"><?= htmlspecialchars($currentSettings['stat_hdr_num'] ?? '4K HDR') ?></div>
                            <div style="font-size: 0.65rem; color: var(--text-muted);">Standard</div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

        <!-- Social Media & Contact Info Settings Panel -->
        <div class="glass-panel" style="padding: 28px 30px; margin-bottom: 28px;">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 20px; padding-bottom: 14px; border-bottom: 1px solid var(--glass-border);">
                <span style="font-size: 1.4rem;">📱</span>
                <div>
                    <h2 style="font-size: 1.15rem; font-weight: 600; color: #fff; margin: 0;">Social Media & Direct Contact Info</h2>
                    <span style="font-size: 0.78rem; color: var(--accent-gold);">Controls phone numbers and clickable social media buttons across all website footers and contact areas</span>
                </div>
            </div>

            <!-- Phone Numbers Row -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 24px;">
                <div class="form-group">
                    <label class="form-label" for="app_phone">
                        <span>Display Phone Number (Formatted)</span>
                    </label>
                    <input 
                        type="text" 
                        id="app_phone" 
                        name="app_phone" 
                        class="form-input" 
                        value="<?= htmlspecialchars($currentSettings['app_phone'] ?? '+251 91 123 4567') ?>" 
                        placeholder="+251 91 123 4567"
                        required
                    >
                    <small style="color: var(--text-muted); font-size: 0.75rem; display: block; margin-top: 4px;">
                        Shown as text in footers and contact inquiry sections.
                    </small>
                </div>

                <div class="form-group">
                    <label class="form-label" for="app_phone_raw">
                        <span>Dialable Numeric Phone (for tel: links)</span>
                    </label>
                    <input 
                        type="text" 
                        id="app_phone_raw" 
                        name="app_phone_raw" 
                        class="form-input" 
                        value="<?= htmlspecialchars($currentSettings['app_phone_raw'] ?? '+251911234567') ?>" 
                        placeholder="+251911234567"
                        required
                    >
                    <small style="color: var(--text-muted); font-size: 0.75rem; display: block; margin-top: 4px;">
                        Used in <code>href="tel:..."</code> for 1-click dialing on mobile phones.
                    </small>
                </div>
            </div>

            <!-- Social Media Channels Grid -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 20px;">
                
                <div class="form-group">
                    <label class="form-label" for="social_telegram" style="display: flex; align-items: center; gap: 8px;">
                        <span>✈️ Telegram Channel / Handle URL</span>
                    </label>
                    <input 
                        type="url" 
                        id="social_telegram" 
                        name="social_telegram" 
                        class="form-input" 
                        value="<?= htmlspecialchars($currentSettings['social_telegram'] ?? 'https://t.me/barokproduction') ?>" 
                        placeholder="https://t.me/barokproduction"
                        required
                    >
                </div>

                <div class="form-group">
                    <label class="form-label" for="social_instagram" style="display: flex; align-items: center; gap: 8px;">
                        <span>📷 Instagram Profile URL</span>
                    </label>
                    <input 
                        type="url" 
                        id="social_instagram" 
                        name="social_instagram" 
                        class="form-input" 
                        value="<?= htmlspecialchars($currentSettings['social_instagram'] ?? 'https://instagram.com/barokproduction') ?>" 
                        placeholder="https://instagram.com/barokproduction"
                        required
                    >
                </div>

                <div class="form-group">
                    <label class="form-label" for="social_tiktok" style="display: flex; align-items: center; gap: 8px;">
                        <span>🎵 TikTok Profile URL</span>
                    </label>
                    <input 
                        type="url" 
                        id="social_tiktok" 
                        name="social_tiktok" 
                        class="form-input" 
                        value="<?= htmlspecialchars($currentSettings['social_tiktok'] ?? 'https://tiktok.com/@barokproduction') ?>" 
                        placeholder="https://tiktok.com/@barokproduction"
                        required
                    >
                </div>

                <div class="form-group">
                    <label class="form-label" for="social_youtube" style="display: flex; align-items: center; gap: 8px;">
                        <span>▶️ YouTube Channel URL</span>
                    </label>
                    <input 
                        type="url" 
                        id="social_youtube" 
                        name="social_youtube" 
                        class="form-input" 
                        value="<?= htmlspecialchars($currentSettings['social_youtube'] ?? 'https://youtube.com/@barokproduction') ?>" 
                        placeholder="https://youtube.com/@barokproduction"
                        required
                    >
                </div>

                <div class="form-group">
                    <label class="form-label" for="social_facebook" style="display: flex; align-items: center; gap: 8px;">
                        <span>👥 Facebook Page URL</span>
                    </label>
                    <input 
                        type="url" 
                        id="social_facebook" 
                        name="social_facebook" 
                        class="form-input" 
                        value="<?= htmlspecialchars($currentSettings['social_facebook'] ?? 'https://facebook.com/barokproduction') ?>" 
                        placeholder="https://facebook.com/barokproduction"
                        required
                    >
                </div>

            </div>
        </div>

        <!-- Save Button Bar -->
        <div class="glass-panel" style="padding: 20px 30px; display: flex; justify-content: space-between; align-items: center;">
            <span style="color: var(--text-muted); font-size: 0.88rem;">
                Changes will take effect instantly on the home page.
            </span>
            <button type="submit" class="btn btn-primary" style="padding: 12px 36px; font-size: 0.95rem;">
                <span>💾 Save Site Settings & Metrics</span>
            </button>
        </div>
    </form>
</div>

<script>
// Realtime preview handlers
document.getElementById('hero_bg_image')?.addEventListener('input', function(e) {
    const img = document.getElementById('posterPreviewImg');
    if (img && e.target.value.trim()) {
        img.src = e.target.value.trim();
    }
});

document.getElementById('stat_shoots_num')?.addEventListener('input', function(e) {
    const el = document.getElementById('previewShoots');
    if (el) el.textContent = e.target.value || '150+';
});

document.getElementById('stat_rating_num')?.addEventListener('input', function(e) {
    const el = document.getElementById('previewRating');
    if (el) el.textContent = e.target.value || '99.8%';
});

document.getElementById('stat_awards_num')?.addEventListener('input', function(e) {
    const el = document.getElementById('previewAwards');
    if (el) el.textContent = e.target.value || '18';
});

document.getElementById('stat_hdr_num')?.addEventListener('input', function(e) {
    const el = document.getElementById('previewHdr');
    if (el) el.textContent = e.target.value || '4K HDR';
});
</script>

</main>
</div>
</body>
</html>
