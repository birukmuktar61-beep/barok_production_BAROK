-- ==========================================================
-- BAROK PRODUCTION - Update Portfolio with Comprehensive Categories
-- Categories:
--  - music-video (Music Videos)
--  - wedding (Wedding Photography & Cinematography)
--  - commercial (Commercial & Brand Ads)
--  - fashion-model (Fashion & Model)
--  - birthday (Birthday Shoots)
--  - baby-shower (Baby Shower & Newborn)
--  - tiktok-reels (TikTok & Social Reels)
--  - youtube (YouTube Content)
--  - podcast (Studio Podcasts)
--  - event (Live Events & Gala)
--  - product-photo (Product & Commercial Photo)
--  - portrait (Portraits & Headshots)
--  - drone (Drone & Aerial Cinematography)
-- ==========================================================

USE `barok_production`;

-- Clear existing sample portfolio items to install the full showcase
DELETE FROM `portfolio`;

INSERT INTO `portfolio` 
(`title`, `category`, `client_name`, `project_year`, `media_type`, `thumbnail_url`, `media_url`, `description`, `is_featured`, `sort_order`) 
VALUES
-- 1. MUSIC VIDEOS
(
    'Neon Horizon - Official Visualizer',
    'music-video',
    'Solstice Records',
    2026,
    'video',
    'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Futuristic sci-fi aesthetic music video captured across industrial locations with anamorphic lenses and dynamic neon lighting.',
    1,
    1
),
(
    'Addis Groove - Afrobeats Hit Single',
    'music-video',
    'Roha Sounds',
    2026,
    'video',
    'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'High-energy musical dance cinematography featuring rooftop choreography in Bole, warm filmic color grading, and speed ramping.',
    1,
    2
),

-- 2. WEDDING (PHOTO & CINEMATOGRAPHY)
(
    'Dawit & Selam - Royal Entoto Wedding Film',
    'wedding',
    'Dawit & Selam',
    2026,
    'video',
    'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Breathtaking cinematic wedding film on Entoto Mountain with Habesha Kemis elegance, emotional vows, and golden twilight drone footage.',
    1,
    3
),
(
    'Covenant in Gold - Cathedral Nuptials',
    'wedding',
    'Yonas & Meron',
    2025,
    'image',
    'https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1600&q=85',
    'High-resolution bridal portraiture capturing intricate Ethiopian Orthodox coronation crowns, gold embroidery, and sacred cathedral grandeur.',
    1,
    4
),

-- 3. COMMERCIAL & BRAND ADS
(
    'Elysian Chrono - Luxury Timepiece Launch',
    'commercial',
    'Elysian Horology',
    2026,
    'video',
    'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Macro cinematography highlighting micro-mechanics, sapphire crystal reflections, and timeless elegance for international launch campaign.',
    1,
    5
),
(
    'Tomoca Reserve - Ethiopian Single-Origin Espresso',
    'commercial',
    'Tomoca Coffee Roasters',
    2026,
    'video',
    'https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Sensory brand documentary following hand-harvested Yirgacheffe coffee beans, wood-fire roasting, and creamy crema extraction.',
    1,
    6
),

-- 4. FASHION & MODEL
(
    'Velvet Obsidian - Haute Couture Autumn Lookbook',
    'fashion-model',
    'Maison Barok',
    2026,
    'image',
    'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=1600&q=85',
    'Editorial lookbook shot with moody glass reflections, dramatic silhouettes, and vibrant velvet texture rendering.',
    1,
    7
),
(
    'Habesha Modernism - Runway Editorial',
    'fashion-model',
    'Addis Fashion Week',
    2026,
    'image',
    'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1600&q=85',
    'Avant-garde studio session merging traditional handwoven Tibeb fabrics with contemporary streetwear silhouettes and bold styling.',
    0,
    8
),

-- 5. BIRTHDAY SHOOTS
(
    'Golden Jubilation - 30th Birthday Gala',
    'birthday',
    'Hellen Tadesse',
    2026,
    'image',
    'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=1600&q=85',
    'Glamorous milestone celebration shoot with warm tungsten studio lighting, champagne sparkles, and custom golden typography backdrop.',
    1,
    9
),
(
    'Little Explorer - 1st Cake Smash Fiesta',
    'birthday',
    'Kaleb & Family',
    2026,
    'image',
    'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=1600&q=85',
    'Vibrant, joyful first birthday photography with custom safari jungle props, organic balloon garland, and adorable messy cake smash moments.',
    0,
    10
),

-- 6. BABY SHOWER & NEWBORN
(
    'Blooming Miracle - Botanical Baby Shower',
    'baby-shower',
    'Bethlehem & Michael',
    2026,
    'image',
    'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=1600&q=85',
    'Pastel floral maternity and baby shower portraits, capturing intimate family excitement, soft natural sunlight, and heirloom gifts.',
    1,
    11
),
(
    'Little Angel - Newborn Serenity',
    'baby-shower',
    'Dr. Henok Family',
    2025,
    'image',
    'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=1600&q=85',
    'Peaceful studio newborn photography with gentle warming lights, hand-knitted organic wraps, and tender parent cuddles.',
    0,
    12
),

-- 7. TIKTOK & REELS
(
    'Street Style Addis - Viral 9:16 Transitions',
    'tiktok-reels',
    'Urban Vibe ET',
    2026,
    'video',
    'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Fast-paced vertical reel with kinetic typography, beat-matched jump cuts, and vibrant Addis Ababa street fashion aesthetics.',
    1,
    13
),
(
    'Chef Secret Sauce - 30s Viral Culinary Hook',
    'tiktok-reels',
    'Bole Bistro Kitchen',
    2026,
    'video',
    'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Sizzling macro vertical video with speed ramping, ASMR cooking audio, and high-conversion hooks for Instagram and TikTok.',
    0,
    14
),

-- 8. YOUTUBE CONTENT
(
    'The Creative Studio - Ep. 12 Masterclass',
    'youtube',
    'Barok Creative Tech',
    2026,
    'video',
    'https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Dual-cam 4K episodic YouTube masterclass detailing cinema anamorphic rigs, light diffusers, and DaVinci color grading workflow.',
    1,
    15
),
(
    'Addis Urban Diary - Tech & Lifestyle Vlog',
    'youtube',
    'Nati Lifestyle Channel',
    2026,
    'video',
    'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Cinematic YouTube travel and lifestyle vlog exploring coffee houses, architectural hubs, and creative incubators in the capital.',
    0,
    16
),

-- 9. PODCASTS
(
    'Tech Diaspora Dialogue - 4K Studio Broadcast',
    'podcast',
    'Shega Media Network',
    2026,
    'video',
    'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Tri-camera studio setup with Shure SM7B microphones, subtle RGB mood accents, and crystal-clear audio mastering.',
    1,
    17
),
(
    'Vocal Booth Sessions - Deep Soul Talks',
    'podcast',
    'Acoustic Hub Addis',
    2025,
    'video',
    'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Intimate fireside podcast recording with live acoustic musical interludes and deep conversational lighting design.',
    0,
    18
),

-- 10. LIVE EVENTS & GALA
(
    'Summit Red Bull Arena - Championship Cup',
    'event',
    'Apex Motorsport',
    2025,
    'video',
    'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Adrenaline-packed cinematic recap of the 2025 championship cup, featuring high-speed FPV drone chases and paddock drama.',
    1,
    19
),
(
    'Addis International Tech Expo - Keynote Gala',
    'event',
    'Ministry of Innovation',
    2026,
    'image',
    'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1600&q=85',
    'High-energy corporate summit photography capturing keynote presentations, VIP networking, and dynamic exhibition halls.',
    0,
    20
),

-- 11. PRODUCT / COMMERCIAL PHOTO
(
    'Sheba Leather - Handcrafted Luxury Bags',
    'product-photo',
    'Sheba Artisan Leather',
    2026,
    'image',
    'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=1600&q=85',
    'Studio macro focus-stacked product photography showcasing genuine full-grain Ethiopian leather texture, brass buckles, and precise stitching.',
    1,
    21
),
(
    'Nebula Wireless Earbuds - Tech Commercial Stills',
    'product-photo',
    'Aura Audio Technologies',
    2026,
    'image',
    'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=1600&q=85',
    'Sleek high-tech e-commerce photography with matte black floating pedestals, caustic water reflections, and cyan neon glow.',
    0,
    22
),

-- 12. PORTRAIT & HEADSHOTS
(
    'Monochrome Soul - Acoustic Studio Session',
    'portrait',
    'Maya Lin Quartet',
    2025,
    'image',
    'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1600&q=85',
    'Intimate high-contrast black & white portraiture capturing the raw emotion and acoustic resonance of live studio recording.',
    1,
    23
),
(
    'Executive Presence - Fintech Board Headshots',
    'portrait',
    'Dashen Innovation Labs',
    2026,
    'image',
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1600&q=85',
    'Sharp executive studio headshots with subtle rim lighting and clean minimalist slate grey backdrops for Forbes feature.',
    0,
    24
),

-- 13. DRONE & AERIAL
(
    'Skyline Echoes - 4K Architectural Aerials',
    'drone',
    'Metropolis Skyline',
    2026,
    'video',
    'https://images.unsplash.com/photo-1477959858617-67f30bc75b82?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Golden hour cinematic drone passes capturing modern glass architectural monoliths and twilight urban energy.',
    1,
    25
),
(
    'Abyssinian Highlands - 4K Rift Valley Expedition',
    'drone',
    'Ethiopian Wildlife Authority',
    2026,
    'video',
    'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
    'https://www.youtube.com/embed/dQw4w9WgXcQ',
    'Licensed high-altitude drone cinematography soaring across lush green escarpments, waterfalls, and mist-covered mountain passes.',
    0,
    26
);
