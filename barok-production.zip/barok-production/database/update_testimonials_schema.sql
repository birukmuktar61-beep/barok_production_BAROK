-- ==========================================================
-- BAROK PRODUCTION - Testimonials Schema & Seed Migration
-- ==========================================================

USE `barok_production`;

CREATE TABLE IF NOT EXISTS `testimonials` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `client_name` VARCHAR(120) NOT NULL,
    `client_role` VARCHAR(150) DEFAULT NULL,
    `project_type` VARCHAR(100) DEFAULT NULL,
    `rating` TINYINT NOT NULL DEFAULT 5,
    `review_text` TEXT NOT NULL,
    `is_approved` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed initial approved testimonials if table is empty
INSERT INTO `testimonials` (`client_name`, `client_role`, `project_type`, `rating`, `review_text`, `is_approved`)
SELECT 'Soren Knight', 'Lead Artist, Solstice Records', 'Music Video', 5, 'The music video BAROK PRODUCTION delivered surpassed every expectation. Their lighting setups and anamorphic lenses gave our song a theatrical grandeur that went viral instantly.', 1
WHERE NOT EXISTS (SELECT 1 FROM `testimonials` WHERE `client_name` = 'Soren Knight');

INSERT INTO `testimonials` (`client_name`, `client_role`, `project_type`, `rating`, `review_text`, `is_approved`)
SELECT 'Elena Hartman', 'Brand Director, Elysian Horology', 'Commercial Video', 5, 'Flawless turnaround and macro cinematography. They brought our luxury timepiece campaign to life with unbelievable precision. Our conversions increased by 42% on product launch day.', 1
WHERE NOT EXISTS (SELECT 1 FROM `testimonials` WHERE `client_name` = 'Elena Hartman');

INSERT INTO `testimonials` (`client_name`, `client_role`, `project_type`, `rating`, `review_text`, `is_approved`)
SELECT 'Darius Reed', 'Event Producer, Apex Motorsport', 'Event Coverage', 5, 'Booking was seamless. The online booking system let us specify drone requirements and schedules without endless back-and-forth emails. Professional, punctual, and visionary.', 1
WHERE NOT EXISTS (SELECT 1 FROM `testimonials` WHERE `client_name` = 'Darius Reed');
