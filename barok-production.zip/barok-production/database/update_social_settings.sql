﻿-- ==========================================================
-- BAROK PRODUCTION - Add Social & Contact Settings Seeds
-- ==========================================================

USE `barok_production`;

INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_group`, `description`) VALUES
('app_phone', '+251 91 123 4567', 'contact', 'Customer support and booking inquiries phone number'),
('app_phone_raw', '+251911234567', 'contact', 'Raw numeric phone number for tel: link dialing'),
('social_telegram', 'https://t.me/barokproduction', 'social', 'Official Telegram channel or contact handle URL'),
('social_instagram', 'https://instagram.com/barokproduction', 'social', 'Official Instagram profile page URL'),
('social_tiktok', 'https://tiktok.com/@barokproduction', 'social', 'Official TikTok profile handle URL'),
('social_youtube', 'https://youtube.com/@barokproduction', 'social', 'Official YouTube video channel URL'),
('social_facebook', 'https://facebook.com/barokproduction', 'social', 'Official Facebook page or group URL')
ON DUPLICATE KEY UPDATE 
    `setting_group` = VALUES(`setting_group`),
    `description` = VALUES(`description`);
