﻿-- ==========================================================
-- BAROK PRODUCTION - Site Settings & Dynamic Metrics Table
-- ==========================================================

USE `barok_production`;

CREATE TABLE IF NOT EXISTS `settings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(80) NOT NULL UNIQUE,
    `setting_value` TEXT DEFAULT NULL,
    `setting_group` VARCHAR(50) DEFAULT 'general',
    `description` VARCHAR(255) DEFAULT NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed Default Settings
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_group`, `description`) VALUES
('hero_video_url', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'hero', 'Hero Reel Embed/Direct Video URL (YouTube, Vimeo, or MP4)'),
('hero_bg_image', 'https://images.unsplash.com/photo-1518135714426-c18f5ffb6f4d?auto=format&fit=crop&w=1600&q=80', 'hero', 'Hero Reel Preview Poster / Camera Rig Image'),
('stat_shoots_num', '150+', 'metrics', 'Total Commercial & Music Shoots count'),
('stat_rating_num', '99.8%', 'metrics', 'Client Approval Rating percentage'),
('stat_awards_num', '18', 'metrics', 'Festival & Industry Awards count'),
('stat_hdr_num', '4K HDR', 'metrics', 'Master Color & Video Standard badge')
ON DUPLICATE KEY UPDATE 
    `setting_value` = VALUES(`setting_value`),
    `description` = VALUES(`description`);
