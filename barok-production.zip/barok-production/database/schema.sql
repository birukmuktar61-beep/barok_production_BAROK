-- ==========================================================
-- BAROK PRODUCTION - Database Schema & Initial Seed Data
-- ==========================================================

CREATE DATABASE IF NOT EXISTS `barok_production` 
DEFAULT CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE `barok_production`;

-- 1. Admin Users Table
CREATE TABLE IF NOT EXISTS `admins` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `role` ENUM('superadmin', 'manager', 'editor') DEFAULT 'manager',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `last_login` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB;

-- 2. Services & Packages Table
CREATE TABLE IF NOT EXISTS `services` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(150) NOT NULL,
    `service_type` ENUM('photo', 'video', 'both') DEFAULT 'photo',
    `category` VARCHAR(80) NOT NULL,
    `price` DECIMAL(10,2) NOT NULL,
    `duration_hours` INT DEFAULT 4,
    `short_desc` VARCHAR(255) NOT NULL,
    `features` TEXT NOT NULL,
    `is_featured` TINYINT(1) DEFAULT 0,
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Portfolio Projects Table
CREATE TABLE IF NOT EXISTS `portfolio` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(180) NOT NULL,
    `category` VARCHAR(80) NOT NULL,
    `client_name` VARCHAR(120) DEFAULT NULL,
    `project_year` INT DEFAULT 2026,
    `media_type` ENUM('image', 'video') DEFAULT 'image',
    `thumbnail_url` TEXT NOT NULL,
    `media_url` TEXT DEFAULT NULL,
    `description` TEXT DEFAULT NULL,
    `is_featured` TINYINT(1) DEFAULT 0,
    `sort_order` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 4. Bookings Table
CREATE TABLE IF NOT EXISTS `bookings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `reference_code` VARCHAR(20) NOT NULL UNIQUE,
    `client_name` VARCHAR(120) NOT NULL,
    `client_email` VARCHAR(150) NOT NULL,
    `client_phone` VARCHAR(40) NOT NULL,
    `service_id` INT NOT NULL,
    `booking_date` DATE NOT NULL,
    `booking_time` VARCHAR(20) NOT NULL,
    `shoot_location` VARCHAR(255) NOT NULL,
    `project_notes` TEXT DEFAULT NULL,
    `add_ons` TEXT DEFAULT NULL,
    `total_price` DECIMAL(10,2) NOT NULL,
    `status` ENUM('pending', 'confirmed', 'in_progress', 'completed', 'cancelled') DEFAULT 'pending',
    `admin_notes` TEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`service_id`) REFERENCES `services`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 5. General Contact & Inquiries Table
CREATE TABLE IF NOT EXISTS `inquiries` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(120) NOT NULL,
    `email` VARCHAR(150) NOT NULL,
    `subject` VARCHAR(200) NOT NULL,
    `message` TEXT NOT NULL,
    `is_read` TINYINT(1) DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 6. Testimonials Table
CREATE TABLE IF NOT EXISTS `testimonials` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `client_name` VARCHAR(120) NOT NULL,
    `client_role` VARCHAR(150) DEFAULT NULL,
    `project_type` VARCHAR(100) DEFAULT NULL,
    `rating` TINYINT NOT NULL DEFAULT 5,
    `review_text` TEXT NOT NULL,
    `is_approved` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 7. Site Settings & Metrics Table
CREATE TABLE IF NOT EXISTS `settings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(80) NOT NULL UNIQUE,
    `setting_value` TEXT DEFAULT NULL,
    `setting_group` VARCHAR(50) DEFAULT 'general',
    `description` VARCHAR(255) DEFAULT NULL,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ==========================================================
-- SEED DATA
-- ==========================================================

-- Default Admin User (Password: Admin@12345)
INSERT INTO `admins` (`name`, `email`, `password_hash`, `role`)
SELECT 'Barok Production Admin', 'admin@barokproduction.com', '$2y$10$BJ7hpWucLKFa.91g42SE4uEfrIUCMsxRZhArlJ1A4K8mcN48G8tZC', 'superadmin'
WHERE NOT EXISTS (SELECT 1 FROM `admins` WHERE `email` = 'admin@barokproduction.com');

-- Initial Service Packages
INSERT INTO `services` (`title`, `category`, `price`, `duration_hours`, `short_desc`, `features`, `is_featured`)
VALUES
(
    'Cinematic Music Video Production',
    'Music Video',
    1850.00,
    8,
    'End-to-end cinematic music video with multi-camera 4K capture, lighting design, and grading.',
    '["Full 4K Cinema Camera Rig (Sony FX6 / RED)", "Professional Lighting & Gimbal Operator", "Color Grading & Cinematic Sound Design", "2 Rounds of Client Revisions", "Teaser Reel for Instagram & TikTok (9:16)"]',
    1
),
(
    'Brand & Commercial Storytelling',
    'Commercial',
    1450.00,
    6,
    'High-converting product or brand documentary video crafted to elevate your enterprise presence.',
    '["Concept & Storyboard Ideation", "4K Video & Drone Aerial B-Roll", "Studio Audio Recording & Voiceover Sync", "Licensed Soundtrack & Motion Graphics", "30s, 60s and Full 2-Minute Cuts"]',
    1
),
(
    'VIP Event & Fashion Coverage',
    'Event Coverage',
    950.00,
    5,
    'Live action coverage for gala nights, album launches, fashion runways, and corporate summits.',
    '["Dual-Videographer Coverage", "Full Highlight Reel (3-5 Minutes)", "Same-Day Social Media Clip", "High-Resolution Raw Footage Delivery", "Uncapped Still Photography Selects"]',
    0
),
(
    'Studio & Editorial Portraiture',
    'Photography',
    550.00,
    3,
    'Editorial, artist headshots, album cover shoots, and high-fashion studio portraits.',
    '["Studio or Outdoor Location", "Custom Lighting Setup & Creative Direction", "25 Master Retouched High-Res Images", "Full Digital Gallery with Download Access", "Print-Ready Licensing"]',
    0
);

-- Initial Portfolio Showcase Items (Comprehensive Ethiopian & International Productions)
INSERT INTO `portfolio` (`title`, `category`, `client_name`, `project_year`, `media_type`, `thumbnail_url`, `media_url`, `description`, `is_featured`, `sort_order`)
VALUES
-- 1. Music Videos
('Neon Horizon - Official Visualizer', 'music-video', 'Solstice Records', 2026, 'video', 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Futuristic sci-fi aesthetic music video captured across industrial locations with anamorphic lenses and dynamic neon lighting.', 1, 1),
('Addis Groove - Afrobeats Hit Single', 'music-video', 'Roha Sounds', 2026, 'video', 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'High-energy musical dance cinematography featuring rooftop choreography in Bole, warm filmic color grading, and speed ramping.', 1, 2),

-- 2. Wedding (Photo & Cinematography)
('Dawit & Selam - Royal Entoto Wedding Film', 'wedding', 'Dawit & Selam', 2026, 'video', 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Breathtaking cinematic wedding film on Entoto Mountain with Habesha Kemis elegance, emotional vows, and golden twilight drone footage.', 1, 3),
('Covenant in Gold - Cathedral Nuptials', 'wedding', 'Yonas & Meron', 2025, 'image', 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1600&q=85', 'High-resolution bridal portraiture capturing intricate Ethiopian Orthodox coronation crowns, gold embroidery, and sacred cathedral grandeur.', 1, 4),

-- 3. Commercial & Brand Ads
('Elysian Chrono - Luxury Timepiece Launch', 'commercial', 'Elysian Horology', 2026, 'video', 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Macro cinematography highlighting micro-mechanics, sapphire crystal reflections, and timeless elegance for international launch campaign.', 1, 5),
('Tomoca Reserve - Ethiopian Single-Origin Espresso', 'commercial', 'Tomoca Coffee Roasters', 2026, 'video', 'https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Sensory brand documentary following hand-harvested Yirgacheffe coffee beans, wood-fire roasting, and creamy crema extraction.', 1, 6),

-- 4. Fashion & Model
('Velvet Obsidian - Haute Couture Autumn Lookbook', 'fashion-model', 'Maison Barok', 2026, 'image', 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=1600&q=85', 'Editorial lookbook shot with moody glass reflections, dramatic silhouettes, and vibrant velvet texture rendering.', 1, 7),
('Habesha Modernism - Runway Editorial', 'fashion-model', 'Addis Fashion Week', 2026, 'image', 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1600&q=85', 'Avant-garde studio session merging traditional handwoven Tibeb fabrics with contemporary streetwear silhouettes and bold styling.', 0, 8),

-- 5. Birthday Shoots
('Golden Jubilation - 30th Birthday Gala', 'birthday', 'Hellen Tadesse', 2026, 'image', 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=1600&q=85', 'Glamorous milestone celebration shoot with warm tungsten studio lighting, champagne sparkles, and custom golden typography backdrop.', 1, 9),
('Little Explorer - 1st Cake Smash Fiesta', 'birthday', 'Kaleb & Family', 2026, 'image', 'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=1600&q=85', 'Vibrant, joyful first birthday photography with custom safari jungle props, organic balloon garland, and adorable messy cake smash moments.', 0, 10),

-- 6. Baby Shower & Newborn
('Blooming Miracle - Botanical Baby Shower', 'baby-shower', 'Bethlehem & Michael', 2026, 'image', 'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=1600&q=85', 'Pastel floral maternity and baby shower portraits, capturing intimate family excitement, soft natural sunlight, and heirloom gifts.', 1, 11),
('Little Angel - Newborn Serenity', 'baby-shower', 'Dr. Henok Family', 2025, 'image', 'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=1600&q=85', 'Peaceful studio newborn photography with gentle warming lights, hand-knitted organic wraps, and tender parent cuddles.', 0, 12),

-- 7. TikTok & Reels
('Street Style Addis - Viral 9:16 Transitions', 'tiktok-reels', 'Urban Vibe ET', 2026, 'video', 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Fast-paced vertical reel with kinetic typography, beat-matched jump cuts, and vibrant Addis Ababa street fashion aesthetics.', 1, 13),
('Chef Secret Sauce - 30s Viral Culinary Hook', 'tiktok-reels', 'Bole Bistro Kitchen', 2026, 'video', 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Sizzling macro vertical video with speed ramping, ASMR cooking audio, and high-conversion hooks for Instagram and TikTok.', 0, 14),

-- 8. YouTube Content
('The Creative Studio - Ep. 12 Masterclass', 'youtube', 'Barok Creative Tech', 2026, 'video', 'https://images.unsplash.com/photo-1598899134739-24c46f58b8c0?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Dual-cam 4K episodic YouTube masterclass detailing cinema anamorphic rigs, light diffusers, and DaVinci color grading workflow.', 1, 15),
('Addis Urban Diary - Tech & Lifestyle Vlog', 'youtube', 'Nati Lifestyle Channel', 2026, 'video', 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Cinematic YouTube travel and lifestyle vlog exploring coffee houses, architectural hubs, and creative incubators in the capital.', 0, 16),

-- 9. Podcasts
('Tech Diaspora Dialogue - 4K Studio Broadcast', 'podcast', 'Shega Media Network', 2026, 'video', 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Tri-camera studio setup with Shure SM7B microphones, subtle RGB mood accents, and crystal-clear audio mastering.', 1, 17),
('Vocal Booth Sessions - Deep Soul Talks', 'podcast', 'Acoustic Hub Addis', 2025, 'video', 'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Intimate fireside podcast recording with live acoustic musical interludes and deep conversational lighting design.', 0, 18),

-- 10. Live Events & Gala
('Summit Red Bull Arena - Championship Cup', 'event', 'Apex Motorsport', 2025, 'video', 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Adrenaline-packed cinematic recap of the 2025 championship cup, featuring high-speed FPV drone chases and paddock drama.', 1, 19),
('Addis International Tech Expo - Keynote Gala', 'event', 'Ministry of Innovation', 2026, 'image', 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1600&q=85', 'High-energy corporate summit photography capturing keynote presentations, VIP networking, and dynamic exhibition halls.', 0, 20),

-- 11. Product / Commercial Photo
('Sheba Leather - Handcrafted Luxury Bags', 'product-photo', 'Sheba Artisan Leather', 2026, 'image', 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=1600&q=85', 'Studio macro focus-stacked product photography showcasing genuine full-grain Ethiopian leather texture, brass buckles, and precise stitching.', 1, 21),
('Nebula Wireless Earbuds - Tech Commercial Stills', 'product-photo', 'Aura Audio Technologies', 2026, 'image', 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=1600&q=85', 'Sleek high-tech e-commerce photography with matte black floating pedestals, caustic water reflections, and cyan neon glow.', 0, 22),

-- 12. Portrait & Headshots
('Monochrome Soul - Acoustic Studio Session', 'portrait', 'Maya Lin Quartet', 2025, 'image', 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?auto=format&fit=crop&w=1600&q=85', 'Intimate high-contrast black & white portraiture capturing the raw emotion and acoustic resonance of live studio recording.', 1, 23),
('Executive Presence - Fintech Board Headshots', 'portrait', 'Dashen Innovation Labs', 2026, 'image', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1600&q=85', 'Sharp executive studio headshots with subtle rim lighting and clean minimalist slate grey backdrops for Forbes feature.', 0, 24),

-- 13. Drone & Aerial
('Skyline Echoes - 4K Architectural Aerials', 'drone', 'Metropolis Skyline', 2026, 'video', 'https://images.unsplash.com/photo-1477959858617-67f30bc75b82?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Golden hour cinematic drone passes capturing modern glass architectural monoliths and twilight urban energy.', 1, 25),
('Abyssinian Highlands - 4K Rift Valley Expedition', 'drone', 'Ethiopian Wildlife Authority', 2026, 'video', 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'Licensed high-altitude drone cinematography soaring across lush green escarpments, waterfalls, and mist-covered mountain passes.', 0, 26);

-- Initial Site Settings & Metrics
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_group`, `description`) VALUES
('hero_video_url', 'https://www.youtube.com/embed/dQw4w9WgXcQ', 'hero', 'Hero Reel Embed/Direct Video URL (YouTube, Vimeo, or MP4)'),
('hero_bg_image', 'https://images.unsplash.com/photo-1518135714426-c18f5ffb6f4d?auto=format&fit=crop&w=1600&q=80', 'hero', 'Hero Reel Preview Poster / Camera Rig Image'),
('stat_shoots_num', '150+', 'metrics', 'Total Commercial & Music Shoots count'),
('stat_rating_num', '99.8%', 'metrics', 'Client Approval Rating percentage'),
('stat_awards_num', '18', 'metrics', 'Festival & Industry Awards count'),
('stat_hdr_num', '4K HDR', 'metrics', 'Master Color & Video Standard badge'),
('app_phone', '+251 91 123 4567', 'contact', 'Customer support and booking inquiries phone number'),
('app_phone_raw', '+251911234567', 'contact', 'Raw numeric phone number for tel: link dialing'),
('social_telegram', 'https://t.me/barokproduction', 'social', 'Official Telegram channel or contact handle URL'),
('social_instagram', 'https://instagram.com/barokproduction', 'social', 'Official Instagram profile page URL'),
('social_tiktok', 'https://tiktok.com/@barokproduction', 'social', 'Official TikTok profile handle URL'),
('social_youtube', 'https://youtube.com/@barokproduction', 'social', 'Official YouTube video channel URL'),
('social_facebook', 'https://facebook.com/barokproduction', 'social', 'Official Facebook page or group URL')
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);


