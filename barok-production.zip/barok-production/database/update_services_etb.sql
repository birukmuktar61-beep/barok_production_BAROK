-- ==========================================================
-- BAROK PRODUCTION - Update Services Table with Ethiopian Business Logic
-- Currency: Ethiopian Birr (ETB)
-- Service Types: photo, video, both (combo)
-- ==========================================================

USE `barok_production`;

-- Add service_type column if it doesn't exist
ALTER TABLE `services` 
ADD COLUMN IF NOT EXISTS `service_type` ENUM('photo', 'video', 'both') DEFAULT 'photo' AFTER `title`;

-- Clear existing sample services to install the complete Ethiopian production packages
DELETE FROM `services`;

-- 1. PHOTO SERVICES
INSERT INTO `services` (`title`, `service_type`, `category`, `price`, `duration_hours`, `short_desc`, `features`, `is_featured`, `is_active`) VALUES
(
    'Birthday Photo Shoot',
    'photo',
    'Birthday Shoot',
    8000.00,
    2,
    'Vibrant celebration portraits with studio lighting, themed backdrops, and cake-smash setups.',
    '["Studio or Outdoor Location", "25 Master Retouched High-Res Images", "Custom Props & Studio Lighting", "Online High-Speed Download Gallery", "Next-Day Teaser Selects"]',
    1,
    1
),
(
    'Baby Shower & Newborn Photography',
    'photo',
    'Baby Shower / Newborn',
    9500.00,
    3,
    'Heartwarming maternity, baby shower celebrations, and tender newborn milestone sessions.',
    '["Gentle Newborn-Safe Studio Lighting", "30 Master Color Graded Photos", "Family & Sibling Portraits Included", "Private Web Proofing Album", "Customized Keepsake Memory Box"]',
    0,
    1
),
(
    'Wedding Photography Masterclass',
    'photo',
    'Wedding Photography',
    28000.00,
    8,
    'Comprehensive wedding day photo coverage from bridal prep, church blessing, to evening banquet.',
    '["Dual Senior Photographers", "120+ High-End Retouched Album Selects", "Uncapped Color-Corrected Digital Snaps", "Deluxe Velvet Hardcover Photo Album", "Pre-Wedding Couple Engagement Shoot"]',
    1,
    1
),
(
    'Fashion & Model Lookbook',
    'photo',
    'Fashion & Model',
    12000.00,
    4,
    'Haute couture, agency comp cards, lookbooks, and high-fashion editorial magazine sessions.',
    '["Creative Direction & Moodboard Design", "3 Outfit Changes with High-End Lighting", "20 Magazine-Grade Skin Retouches", "High-Resolution TIF/JPG Masters", "Commercial Usage Rights Included"]',
    0,
    1
),
(
    'Live Events & Gala Photography',
    'photo',
    'Live Events',
    15000.00,
    5,
    'High-energy coverage for corporate galas, music concerts, album releases, and summits.',
    '["Candid & VIP Red Carpet Coverage", "250+ Edited Event Photos", "Fast 24-Hour Digital Gallery Turnaround", "Social Media Real-Time Highlights", "Full High-Res License"]',
    0,
    1
),
(
    'Product & Commercial Brand Photo',
    'photo',
    'Product / Commercial Photo',
    14000.00,
    4,
    'High-converting product catalog, culinary menu, and e-commerce commercial macro photography.',
    '["Macro Focus-Stacking Detail", "White Background & Lifestyle Studio Setups", "25 Ultra-Sharp Product Selects", "Color Match to Pantone Standards", "Ready for Print & Web Banners"]',
    0,
    1
),
(
    'Custom & Portraiture Shoot',
    'photo',
    'Others',
    6500.00,
    2,
    'Executive headshots, graduation milestones, family portraits, and bespoke photography requests.',
    '["Studio or Selected Addis Location", "15 Professional Retouched Headshots", "High-Resolution Deliverables", "Professional Studio Backdrops", "Expedited Delivery"]',
    0,
    1
);

-- 2. VIDEO SERVICES
INSERT INTO `services` (`title`, `service_type`, `category`, `price`, `duration_hours`, `short_desc`, `features`, `is_featured`, `is_active`) VALUES
(
    'Cinematic Music Video Production',
    'video',
    'Music Videos',
    45000.00,
    10,
    'Top-tier broadcast music video with cinema camera rigs, anamorphic aesthetics, and color grading.',
    '["Sony FX6 / RED 4K Cinema Camera", "Complete Lighting Rig & Gimbal Rigging", "Full Storyboard & Directorial Vision", "DaVinci Resolve Color Grade & Sound Design", "9:16 Social Reels & Teaser Trailers"]',
    1,
    1
),
(
    'TikTok & Instagram Reels Package',
    'video',
    'TikTok & Reels',
    12500.00,
    4,
    'High-engagement vertical video production optimized for viral TikTok, IG Reels, and YouTube Shorts.',
    '["Batch Production: 5 Finished 9:16 Reels", "Trending Sound Sync & Dynamic Captions", "Studio Ring & RGB Ambient Lighting", "Speed Ramping & Hook Editing", "Delivered within 72 Hours"]',
    1,
    1
),
(
    'YouTube Episodic Production',
    'video',
    'YouTube Videos',
    18000.00,
    5,
    'Polished multi-camera studio production for YouTube channels, interviews, and episodic shows.',
    '["Dual 4K Camera Angle Setup", "Studio Boom & Wireless Lavalier Audio", "Custom Motion Intro & Lower Thirds", "Full Cut & Color Correction", "Ready-to-Upload YouTube Export"]',
    0,
    1
),
(
    'Studio Podcast Recording & Cut',
    'video',
    'Podcasts',
    16000.00,
    4,
    'Boutique studio podcast capture with crisp broadcast microphones and multi-angle 4K video.',
    '["Shure SM7B Broadcast Microphones", "3-Camera Multi-Angle Video Switch", "Full Audio Mastering & Noise Cleaning", "Full Episode + 3 Short Viral Clips", "Clean Separate Audio Track Deliverables"]',
    0,
    1
),
(
    'Commercial & Brand Video Ad',
    'video',
    'Commercial & Brand Ads',
    38000.00,
    8,
    'High-impact enterprise documentary, television commercial, and brand campaign storytelling.',
    '["Concept Development & Scriptwriting", "Cinematic 4K Capture & Aerial Drone Shots", "Licensed Music Track & Voiceover Integration", "30s, 60s, and Full 2-Minute Cuts", "Color Grading & Motion Graphics"]',
    1,
    1
),
(
    'Cinematic Wedding Film',
    'video',
    'Cinematic Wedding Video',
    35000.00,
    10,
    'Emotional, cinematic wedding film documenting the beauty, tradition, and celebration of your union.',
    '["Dual Cinematographer Team", "5-7 Minute Highlight Cinema Film", "Full Ceremony & Banquet Documentary Cut", "Drone Aerial Establishing Angles", "Custom USB Wood Box Keepsake"]',
    0,
    1
),
(
    'Drone & Aerial Cinematography',
    'video',
    'Drone & Aerial',
    14000.00,
    3,
    'FAA licensed aerial drone cinematography for architectural, landscape, and outdoor events.',
    '["Licensed Pro Drone Pilot", "4K 60fps / D-Log HDR Aerial Video", "Uncapped Still Aerial Photos", "Smooth Orbit & Fly-Through Movements", "Immediate Raw Footage Transfer"]',
    0,
    1
);

-- 3. BOTH (PHOTO & VIDEO COMBO PACKAGES)
INSERT INTO `services` (`title`, `service_type`, `category`, `price`, `duration_hours`, `short_desc`, `features`, `is_featured`, `is_active`) VALUES
(
    'Full Royal Wedding Package (Photo + Video)',
    'both',
    'Full Wedding Package',
    55000.00,
    12,
    'The ultimate all-inclusive wedding production: dual photographers and dual cinematographers all day.',
    '["2 Senior Photographers + 2 Cinematographers", "Full 4K Cinematic Highlight Film + Raw Speeches", "150+ Master Retouched Photos + Digital Snaps", "Deluxe Leather Photo Album + Drone Aerials", "Complimentary Engagement Photo Session"]',
    1,
    1
),
(
    'Birthday Celebration Combo (Photo + Video)',
    'both',
    'Birthday Combo',
    16000.00,
    4,
    'Complete birthday memory package featuring both a dedicated photographer and video highlights shooter.',
    '["Dedicated Photographer + Videographer", "40 Master Retouched Birthday Photos", "2-Minute 4K Cinematic Recap Video", "Same-Day 9:16 Social Reel for Instagram", "Full Digital Gallery Access"]',
    1,
    1
),
(
    'Event VIP Production Combo (Photo + Video)',
    'both',
    'Event VIP Combo',
    29000.00,
    6,
    'Turnkey media coverage for summits, festivals, concerts, and premier enterprise events.',
    '["Full Media Crew (Photo & Video Teams)", "300+ Edited High-Res Event Photos", "3-5 Minute 4K After-Movie Film", "Daily Express Clips for PR & Marketing", "Unrestricted Commercial Broadcast Licensing"]',
    0,
    1
);
