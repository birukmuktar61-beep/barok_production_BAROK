<?php
/**
 * BAROK PRODUCTION - Ethiopian Calendar Conversion & Formatting Engine
 *
 * Implements standard Julian Day Number (JDN) algorithms for bidirectional
 * conversion between the Ethiopian (Ge'ez) and Gregorian calendars.
 */

declare(strict_types=1);

class EthiopianCalendar
{
    private const ETHIOPIAN_EPOCH_JDN = 1723856; // Meskerem 1, 1 E.C.

    public const MONTHS_AMHARIC = [
        1  => 'መስከረም',
        2  => 'ጥቅምት',
        3  => 'ኅዳር',
        4  => 'ታኅሣሥ',
        5  => 'ጥር',
        6  => 'የካቲት',
        7  => 'መጋቢት',
        8  => 'ሚያዝያ',
        9  => 'ግንቦት',
        10 => 'ሰኔ',
        11 => 'ሐምሌ',
        12 => 'ነሐሴ',
        13 => 'ጳጉሜ'
    ];

    public const MONTHS_ENGLISH = [
        1  => 'Meskerem',
        2  => 'Tikimt',
        3  => 'Hidar',
        4  => 'Tahsas',
        5  => 'Tir',
        6  => 'Yekatit',
        7  => 'Megabit',
        8  => 'Miyazya',
        9  => 'Ginbot',
        10 => 'Sene',
        11 => 'Hamle',
        12 => 'Nehase',
        13 => 'Pagume'
    ];

    public const DAYS_OF_WEEK_AMHARIC = [
        0 => 'እሑድ',
        1 => 'ሰኞ',
        2 => 'ማክሰኞ',
        3 => 'ረቡዕ',
        4 => 'ሐሙስ',
        5 => 'ዓርብ',
        6 => 'ቅዳሜ'
    ];

    /**
     * Convert Gregorian date to Julian Day Number (JDN)
     */
    public static function gregorianToJdn(int $year, int $month, int $day): int
    {
        if ($month <= 2) {
            $year -= 1;
            $month += 12;
        }
        $a = (int)floor($year / 100);
        $b = 2 - $a + (int)floor($a / 4);
        return (int)(floor(365.25 * ($year + 4716)) + floor(30.6001 * ($month + 1)) + $day + $b - 1524);
    }

    /**
     * Convert JDN to Gregorian date
     */
    public static function jdnToGregorian(int $jdn): array
    {
        $j = $jdn + 1402;
        $k = (int)floor(($j - 1) / 1461);
        $l = $j - 1461 * $k;
        $n = (int)floor(($l - 1) / 365) - (int)floor($l / 1461);
        $i = $l - 365 * $n + 30;
        $j = (int)floor((80 * $i) / 2447);
        $day = $i - (int)floor((2447 * $j) / 80);
        $i = (int)floor($j / 11);
        $month = $j + 2 - 12 * $i;
        $year = 4 * $k + $n + $i - 4716;

        return [
            'year'      => $year,
            'month'     => $month,
            'day'       => $day,
            'formatted' => sprintf('%04d-%02d-%02d', $year, $month, $day)
        ];
    }

    /**
     * Convert JDN to Ethiopian date
     */
    public static function jdnToEthiopian(int $jdn): array
    {
        $r = ($jdn - self::ETHIOPIAN_EPOCH_JDN) % 1461;
        $n = ($r % 365) + 365 * (int)floor($r / 1460);
        $year = 4 * (int)floor(($jdn - self::ETHIOPIAN_EPOCH_JDN) / 1461) + (int)floor($r / 365) - (int)floor($r / 1460);
        $month = (int)floor($n / 30) + 1;
        $day = ($n % 30) + 1;

        $monthAm = self::MONTHS_AMHARIC[$month] ?? '';
        $monthEn = self::MONTHS_ENGLISH[$month] ?? '';

        return [
            'year'          => $year,
            'month'         => $month,
            'day'           => $day,
            'month_name_am' => $monthAm,
            'month_name_en' => $monthEn,
            'formatted_am'  => "{$monthAm} {$day} ቀን {$year} ዓ.ም.",
            'formatted_en'  => "{$monthEn} {$day}, {$year} E.C."
        ];
    }

    /**
     * Convert Ethiopian date to JDN
     */
    public static function ethiopianToJdn(int $year, int $month, int $day): int
    {
        return (self::ETHIOPIAN_EPOCH_JDN + 365) + 365 * ($year - 1) + (int)floor($year / 4) + 30 * ($month - 1) + $day - 366;
    }

    /**
     * Convert Gregorian (YYYY-MM-DD or parts) to Ethiopian array
     */
    public static function fromGregorian(int|string $yearOrDate, ?int $month = null, ?int $day = null): array
    {
        if (is_string($yearOrDate)) {
            $parts = explode('-', trim($yearOrDate));
            if (count($parts) === 3) {
                $year  = (int)$parts[0];
                $month = (int)$parts[1];
                $day   = (int)$parts[2];
            } else {
                $time = strtotime($yearOrDate);
                $year  = (int)date('Y', $time);
                $month = (int)date('m', $time);
                $day   = (int)date('d', $time);
            }
        } else {
            $year = $yearOrDate;
        }

        $jdn = self::gregorianToJdn($year, $month ?? 1, $day ?? 1);
        $eth = self::jdnToEthiopian($jdn);
        $eth['gregorian'] = sprintf('%04d-%02d-%02d', $year, $month ?? 1, $day ?? 1);
        return $eth;
    }

    /**
     * Convert Ethiopian date to Gregorian date
     */
    public static function toGregorian(int $ethYear, int $ethMonth, int $ethDay): array
    {
        $jdn = self::ethiopianToJdn($ethYear, $ethMonth, $ethDay);
        return self::jdnToGregorian($jdn);
    }

    /**
     * Format a Gregorian date into dual representation based on language
     */
    public static function formatDual(string $gregorianDateStr, string $lang = 'en'): string
    {
        if (empty($gregorianDateStr) || $gregorianDateStr === '0000-00-00') {
            return '—';
        }

        try {
            $time = strtotime($gregorianDateStr);
            if (!$time) return $gregorianDateStr;

            $y = (int)date('Y', $time);
            $m = (int)date('m', $time);
            $d = (int)date('d', $time);

            $jdn = self::gregorianToJdn($y, $m, $d);
            $eth = self::jdnToEthiopian($jdn);

            $gregFormatted = date('M d, Y', $time);

            if ($lang === 'am') {
                return "{$eth['formatted_am']} ({$gregFormatted})";
            } else {
                return "{$gregFormatted} ({$eth['formatted_en']})";
            }
        } catch (Throwable $e) {
            return $gregorianDateStr;
        }
    }
}
