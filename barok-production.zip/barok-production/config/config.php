<?php
/**
 * BAROK PRODUCTION - Global System Configuration, Localization & Utilities
 */

declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Brand & App Details
define('APP_NAME', 'BAROK PRODUCTION');
define('APP_TAGLINE', 'Visionary Cinematography, Sound & High-Impact Visual Arts');
define('APP_EMAIL', 'contact@barokproduction.com');
define('APP_PHONE', '+251 91 123 4567');
define('APP_PHONE_RAW', '+251911234567');
define('APP_LOCATION', 'Bole Sub-City, Next to Edna Mall, Studio 4B, Addis Ababa, Ethiopia');
define('APP_CURRENCY', 'ETB ');

// Social Media Links
define('SOCIAL_TELEGRAM', 'https://t.me/barokproduction');
define('SOCIAL_INSTAGRAM', 'https://instagram.com/barokproduction');
define('SOCIAL_TIKTOK', 'https://tiktok.com/@barokproduction');
define('SOCIAL_YOUTUBE', 'https://youtube.com/@barokproduction');
define('SOCIAL_FACEBOOK', 'https://facebook.com/barokproduction');

// =========================================================================
// Dual-Language (English / Amharic) Localization Engine
// =========================================================================

$supportedLangs = ['en', 'am'];

// 1. Check GET parameter
if (isset($_GET['lang']) && in_array(strtolower(trim($_GET['lang'])), $supportedLangs, true)) {
    $currentLang = strtolower(trim($_GET['lang']));
    $_SESSION['lang'] = $currentLang;
    setcookie('lang', $currentLang, time() + (86400 * 30), '/'); // 30 days
} elseif (isset($_SESSION['lang']) && in_array($_SESSION['lang'], $supportedLangs, true)) {
    $currentLang = $_SESSION['lang'];
} elseif (isset($_COOKIE['lang']) && in_array($_COOKIE['lang'], $supportedLangs, true)) {
    $currentLang = $_COOKIE['lang'];
    $_SESSION['lang'] = $currentLang;
} else {
    $currentLang = 'en';
    $_SESSION['lang'] = 'en';
}

// 2. Load translations dictionary
$langFile = __DIR__ . '/../lang/' . $currentLang . '.php';
$translations = file_exists($langFile) ? require $langFile : [];

// Fallback dictionary (English) if a key is missing
$fallbackFile = __DIR__ . '/../lang/en.php';
$fallbackTranslations = ($currentLang !== 'en' && file_exists($fallbackFile)) ? require $fallbackFile : [];

/**
 * Translation helper function
 */
function __(string $key, ?string $default = null): string
{
    global $translations, $fallbackTranslations;
    if (isset($translations[$key])) {
        return (string)$translations[$key];
    }
    if (isset($fallbackTranslations[$key])) {
        return (string)$fallbackTranslations[$key];
    }
    return $default ?? $key;
}

/**
 * Get current active language code ('en' or 'am')
 */
function getCurrentLang(): string
{
    global $currentLang;
    return $currentLang ?? 'en';
}

/**
 * Generate a dynamic URL switching language while preserving all other query parameters
 */
function getLangSwitchUrl(string $targetLang): string
{
    $params = $_GET;
    $params['lang'] = $targetLang;
    $queryString = http_build_query($params);
    $script = basename($_SERVER['PHP_SELF'] ?? 'index.php');
    return $script . '?' . $queryString;
}

/**
 * Render the Language Switcher button component
 */
function renderLangSwitcher(): string
{
    $curr = getCurrentLang();
    $enUrl = htmlspecialchars(getLangSwitchUrl('en'));
    $amUrl = htmlspecialchars(getLangSwitchUrl('am'));

    $enActive = $curr === 'en' ? ' active' : '';
    $amActive = $curr === 'am' ? ' active' : '';

    return <<<HTML
    <div class="lang-switcher-wrap" title="Switch Language / ቋንቋ ይቀይሩ">
        <a href="{$enUrl}" class="lang-switch-btn{$enActive}">EN</a>
        <a href="{$amUrl}" class="lang-switch-btn{$amActive}">አማ</a>
    </div>
HTML;
}

// =========================================================================
// General Helper Functions
// =========================================================================

// Helper: Sanitize string
function sanitize(string $input): string
{
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Helper: Format price
function formatPrice(float $amount): string
{
    return APP_CURRENCY . number_format($amount, 2);
}

// Helper: Generate unique booking reference code (e.g. BP-2026-X8Y2)
function generateBookingReference(): string
{
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $code = '';
    for ($i = 0; $i < 4; $i++) {
        $code .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return 'BP-' . date('Y') . '-' . $code;
}

// Helper: CSRF token generation & validation
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrfToken(?string $token): bool
{
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

// Helper: Return JSON response
function jsonResponse(array $data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

// Require Ethiopian Calendar Engine
require_once __DIR__ . '/ethiopian_calendar.php';

// Helper: Format date with dual Gregorian and Ethiopian Calendar representation
function formatDateDual(?string $dateStr, ?string $lang = null): string
{
    if (empty($dateStr)) {
        return '—';
    }
    $lang = $lang ?? getCurrentLang();
    return EthiopianCalendar::formatDual($dateStr, $lang);
}

// =========================================================================
// Dynamic Site Settings Helper Functions
// =========================================================================

/**
 * Cache settings in request memory for performance
 */
$GLOBALS['_BAROK_SETTINGS_CACHE'] = null;

function getAllSettings(?PDO $pdo = null): array
{
    if ($GLOBALS['_BAROK_SETTINGS_CACHE'] !== null) {
        return $GLOBALS['_BAROK_SETTINGS_CACHE'];
    }

    $settings = [
        'hero_video_url'   => 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        'hero_bg_image'    => 'https://images.unsplash.com/photo-1518135714426-c18f5ffb6f4d?auto=format&fit=crop&w=1600&q=80',
        'stat_shoots_num'  => '150+',
        'stat_rating_num'  => '99.8%',
        'stat_awards_num'  => '18',
        'stat_hdr_num'     => '4K HDR',
        'app_phone'        => '+251 91 123 4567',
        'app_phone_raw'    => '+251911234567',
        'social_telegram'  => 'https://t.me/barokproduction',
        'social_instagram' => 'https://instagram.com/barokproduction',
        'social_tiktok'    => 'https://tiktok.com/@barokproduction',
        'social_youtube'   => 'https://youtube.com/@barokproduction',
        'social_facebook'  => 'https://facebook.com/barokproduction'
    ];

    try {
        if (!$pdo && class_exists('Database')) {
            $pdo = Database::getConnection();
        }
        if ($pdo) {
            $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $settings[$row['setting_key']] = $row['setting_value'];
            }
        }
    } catch (Throwable $e) {
        // Fallback to defaults
    }

    $GLOBALS['_BAROK_SETTINGS_CACHE'] = $settings;
    return $settings;
}

function getSetting(string $key, ?string $default = null, ?PDO $pdo = null): string
{
    $settings = getAllSettings($pdo);
    return $settings[$key] ?? ($default ?? '');
}



