/**
 * BAROK PRODUCTION - Interactive Booking Wizard Logic (5-Step)
 * Step 1: Service Type (Photo / Video / Both)
 * Step 2: Package selection (filtered by type)
 * Step 3: Schedule & Location
 * Step 4: Add-ons & Gear
 * Step 5: Contact Info & Review
 */

document.addEventListener('DOMContentLoaded', () => {
    initBookingWizard();
});

function initBookingWizard() {
    let currentStep = 1;
    const totalSteps = 5;

    // State
    const bookingState = {
        serviceType: null,      // 'photo' | 'video' | 'both'
        serviceId: null,
        serviceTitle: '',
        basePrice: 0.00,
        bookingDate: '',
        bookingTime: '01:30 PM - 05:30 PM',
        location: '',
        notes: '',
        addons: [],
        totalPrice: 0.00,
        clientName: '',
        clientEmail: '',
        clientPhone: ''
    };

    // DOM Elements
    const stepNodes    = document.querySelectorAll('.step-node');
    const stepPanels   = document.querySelectorAll('.wizard-step-panel');
    const prevBtn      = document.getElementById('prevStepBtn');
    const nextBtn      = document.getElementById('nextStepBtn');
    const submitBtn    = document.getElementById('submitBookingBtn');
    const livePriceEl  = document.getElementById('liveTotalPrice');
    const packageCards = document.querySelectorAll('.package-select-card');
    const addonCheckboxes = document.querySelectorAll('.addon-checkbox');
    const bookingDateInput = document.getElementById('bookingDate');
    const typeCards    = document.querySelectorAll('.type-card');

    // Set minimum date to tomorrow
    if (bookingDateInput) {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const yyyy = tomorrow.getFullYear();
        const mm   = String(tomorrow.getMonth() + 1).padStart(2, '0');
        const dd   = String(tomorrow.getDate()).padStart(2, '0');
        bookingDateInput.min = `${yyyy}-${mm}-${dd}`;
    }

    // --- Step 1: Service Type Card Interaction ---
    typeCards.forEach(card => {
        card.addEventListener('click', () => {
            typeCards.forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
            bookingState.serviceType = card.getAttribute('data-type');

            // Filter package cards for Step 2
            filterPackagesByType(bookingState.serviceType);

            // Reset previously selected package when type changes
            bookingState.serviceId   = null;
            bookingState.serviceTitle = '';
            bookingState.basePrice   = 0.00;
            packageCards.forEach(c => {
                c.classList.remove('selected');
                const radio = c.querySelector('input[type="radio"]');
                if (radio) radio.checked = false;
            });
            recalculateTotal();
        });
    });

    function filterPackagesByType(type) {
        let visibleCount = 0;
        packageCards.forEach(card => {
            const cardType = card.getAttribute('data-type');
            if (cardType === type) {
                card.classList.remove('hidden-type');
                visibleCount++;
            } else {
                card.classList.add('hidden-type');
                card.classList.remove('selected');
                const radio = card.querySelector('input[type="radio"]');
                if (radio) radio.checked = false;
            }
        });

        const noMsg = document.getElementById('noPackagesMsg');
        if (noMsg) {
            noMsg.style.display = visibleCount === 0 ? 'block' : 'none';
        }
    }

    // Check URL parameters for pre-selected service package
    const urlParams = new URLSearchParams(window.location.search);
    const preselectedPackage = urlParams.get('package');
    if (preselectedPackage) {
        packageCards.forEach(card => {
            if (card.getAttribute('data-id') === preselectedPackage) {
                // Auto-select the type of that package
                const cardType = card.getAttribute('data-type');
                typeCards.forEach(tc => {
                    if (tc.getAttribute('data-type') === cardType) {
                        tc.classList.add('selected');
                    }
                });
                bookingState.serviceType = cardType;
                filterPackagesByType(cardType);
                selectPackageCard(card);
                // Jump to step 2
                currentStep = 2;
                updateStepUI();
            }
        });
    }

    // --- Step 2: Package Card Selection ---
    packageCards.forEach(card => {
        card.addEventListener('click', () => {
            if (!card.classList.contains('hidden-type')) {
                selectPackageCard(card);
            }
        });
    });

    function selectPackageCard(card) {
        packageCards.forEach(c => {
            c.classList.remove('selected');
            const radio = c.querySelector('input[type="radio"]');
            if (radio) radio.checked = false;
        });

        card.classList.add('selected');
        const radio = card.querySelector('input[type="radio"]');
        if (radio) radio.checked = true;

        bookingState.serviceId    = card.getAttribute('data-id');
        bookingState.serviceTitle = card.getAttribute('data-title');
        bookingState.basePrice    = parseFloat(card.getAttribute('data-price')) || 0;

        recalculateTotal();
    }

    // --- Step 4: Addons Checkbox Change ---
    addonCheckboxes.forEach(cb => {
        cb.addEventListener('change', () => {
            const card = cb.closest('.addon-card');
            if (card) {
                card.classList.toggle('selected', cb.checked);
            }
            updateAddonsState();
            recalculateTotal();
        });
    });

    function updateAddonsState() {
        bookingState.addons = [];
        addonCheckboxes.forEach(cb => {
            if (cb.checked) {
                bookingState.addons.push({
                    title: cb.getAttribute('data-title'),
                    price: parseFloat(cb.getAttribute('data-price')) || 0
                });
            }
        });
    }

    function recalculateTotal() {
        let sum = bookingState.basePrice;
        bookingState.addons.forEach(a => { sum += a.price; });
        bookingState.totalPrice = sum;

        if (livePriceEl) {
            livePriceEl.textContent = `ETB ${sum.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
        }
    }

    // --- Update Wizard UI ---
    function updateStepUI() {
        stepNodes.forEach((node, index) => {
            const stepNum = index + 1;
            node.classList.remove('active', 'completed');
            if (stepNum === currentStep) {
                node.classList.add('active');
            } else if (stepNum < currentStep) {
                node.classList.add('completed');
            }
        });

        stepPanels.forEach((panel, index) => {
            const stepNum = index + 1;
            panel.style.display = (stepNum === currentStep) ? 'block' : 'none';
        });

        if (prevBtn) {
            prevBtn.style.display = (currentStep === 1) ? 'none' : 'inline-flex';
        }

        if (nextBtn && submitBtn) {
            if (currentStep === totalSteps) {
                nextBtn.style.display  = 'none';
                submitBtn.style.display = 'inline-flex';
                populateReviewSummary();
            } else {
                nextBtn.style.display  = 'inline-flex';
                submitBtn.style.display = 'none';
            }
        }

        window.scrollTo({ top: 120, behavior: 'smooth' });
    }

    // --- Step Validation ---
    function validateCurrentStep() {
        const i18n = window.BAROK_I18N || {};

        if (currentStep === 1) {
            // Must choose a service type
            if (!bookingState.serviceType) {
                showToast(i18n.selectTypeToast || 'Please select a service type: Photo, Video, or Both.', 'error');
                return false;
            }

        } else if (currentStep === 2) {
            // Must choose a package
            if (!bookingState.serviceId) {
                showToast(i18n.selectPkgToast || 'Please choose a production package.', 'error');
                return false;
            }

        } else if (currentStep === 3) {
            const dateVal = document.getElementById('bookingDate').value;
            const timeVal = document.getElementById('bookingTimeSlot').value;
            const locVal  = document.getElementById('shootLocation').value.trim();

            if (!dateVal) {
                showToast(i18n.selectDateToast || 'Please select your preferred shoot date.', 'error');
                return false;
            }
            if (!locVal) {
                showToast(i18n.selectLocToast || 'Please provide a shoot location or studio address.', 'error');
                return false;
            }

            bookingState.bookingDate = dateVal;
            bookingState.bookingTime = timeVal;
            bookingState.location    = locVal;
            bookingState.notes       = document.getElementById('projectNotes').value.trim();

        } else if (currentStep === 4) {
            // Addons are optional — just update state
            updateAddonsState();
            recalculateTotal();
        }

        return true;
    }

    // --- Review Summary Population (Step 5) ---
    function populateReviewSummary() {
        const totalEl = document.getElementById('summaryTotalReview');
        document.getElementById('summaryService').textContent  = bookingState.serviceTitle;
        document.getElementById('summaryDate').textContent     = `${bookingState.bookingDate} (${bookingState.bookingTime})`;
        document.getElementById('summaryLocation').textContent = bookingState.location;

        const addonsList  = document.getElementById('summaryAddonsList');
        if (addonsList) {
            addonsList.innerHTML = '';
            const noAddonsText = (window.BAROK_I18N && window.BAROK_I18N.noAddons)
                ? window.BAROK_I18N.noAddons
                : 'No additional add-ons selected';

            if (bookingState.addons.length === 0) {
                addonsList.innerHTML = `<li class="text-muted">${noAddonsText}</li>`;
            } else {
                bookingState.addons.forEach(a => {
                    const li = document.createElement('li');
                    li.textContent = `+ ${a.title} (ETB ${a.price.toLocaleString('en-US', { minimumFractionDigits: 2 })})`;
                    addonsList.appendChild(li);
                });
            }
        }

        if (totalEl) {
            totalEl.textContent = `ETB ${bookingState.totalPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
        }
    }

    // --- Navigation Buttons ---
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            if (validateCurrentStep()) {
                if (currentStep < totalSteps) {
                    currentStep++;
                    updateStepUI();
                }
            }
        });
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (currentStep > 1) {
                currentStep--;
                updateStepUI();
            }
        });
    }

    // --- Form Submission ---
    const bookingForm = document.getElementById('bookingWizardForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const clientName  = document.getElementById('clientName').value.trim();
            const clientEmail = document.getElementById('clientEmail').value.trim();
            const clientPhone = document.getElementById('clientPhone').value.trim();

            const i18n = window.BAROK_I18N || {};
            if (!clientName || !clientEmail || !clientPhone) {
                showToast(i18n.fillContactToast || 'Please fill in your name, email, and phone number.', 'error');
                return;
            }

            bookingState.clientName  = clientName;
            bookingState.clientEmail = clientEmail;
            bookingState.clientPhone = clientPhone;

            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span>Processing Booking...</span>';

            const payload = {
                service_id:    bookingState.serviceId,
                booking_date:  bookingState.bookingDate,
                booking_time:  bookingState.bookingTime,
                shoot_location: bookingState.location,
                project_notes: bookingState.notes,
                add_ons:       JSON.stringify(bookingState.addons),
                total_price:   bookingState.totalPrice,
                client_name:   bookingState.clientName,
                client_email:  bookingState.clientEmail,
                client_phone:  bookingState.clientPhone
            };

            try {
                const res    = await fetch('api/book.php', {
                    method:  'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body:    JSON.stringify(payload)
                });
                const result = await res.json();

                if (result.success) {
                    showConfirmationScreen(result.data);
                } else {
                    showToast(result.message || 'Booking submission failed.', 'error');
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = '<span>Confirm & Book Shoot ⚡</span>';
                }
            } catch (err) {
                showToast('Failed to connect to booking server.', 'error');
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<span>Confirm & Book Shoot ⚡</span>';
            }
        });
    }

    // --- Confirmation Screen ---
    function showConfirmationScreen(data) {
        const wizardCard = document.querySelector('.booking-wizard-wrapper');
        if (!wizardCard) return;

        const i18n      = window.BAROK_I18N || {};
        const title     = i18n.confirmedTitle || 'Booking Reserved!';
        const desc      = i18n.confirmedDesc  || 'Your production session with <strong>BAROK PRODUCTION</strong> has been registered. Our production team will review your schedule and contact you shortly.';
        const refLabel  = i18n.refLabel  || 'Your Booking Reference Code';
        const refHint   = i18n.refHint   || 'Save this code to track your booking status online anytime.';
        const btnTrack  = i18n.btnTrack  || 'Track Booking Status';
        const btnHome   = i18n.btnHome   || 'Return to Homepage';
        const langParam = i18n.lang ? `&lang=${encodeURIComponent(i18n.lang)}` : '';

        wizardCard.innerHTML = `
            <div class="glass-panel" style="padding: 50px 30px; text-align: center; border-color: var(--accent-gold);">
                <div style="width: 70px; height: 70px; border-radius: 50%; background: rgba(16, 185, 129, 0.15); border: 2px solid var(--status-confirmed); display: flex; align-items: center; justify-content: center; margin: 0 auto 24px; color: var(--status-confirmed); font-size: 2rem;">
                    ✓
                </div>
                <h2 style="font-size: 2.2rem; margin-bottom: 12px;">${title}</h2>
                <p style="max-width: 550px; margin: 0 auto 28px; color: var(--text-secondary);">
                    ${desc}
                </p>

                <div style="background: rgba(255, 183, 3, 0.08); border: 1px dashed var(--accent-gold); border-radius: var(--border-radius-md); padding: 20px; max-width: 440px; margin: 0 auto 30px;">
                    <span style="font-size: 0.85rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; display: block; margin-bottom: 6px;">${refLabel}</span>
                    <span style="font-family: var(--font-display); font-size: 2.2rem; font-weight: 800; color: var(--accent-gold); letter-spacing: 3px;">${data.reference_code}</span>
                    <p style="font-size: 0.82rem; color: var(--text-secondary); margin-top: 8px;">${refHint}</p>
                </div>

                <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap;">
                    <a href="booking-status.php?ref=${encodeURIComponent(data.reference_code)}${langParam}" class="btn btn-primary">
                        ${btnTrack}
                    </a>
                    <a href="index.php?${langParam.replace('&', '')}" class="btn btn-glass">
                        ${btnHome}
                    </a>
                </div>
            </div>
        `;
    }

    // Initial render
    updateStepUI();
}
