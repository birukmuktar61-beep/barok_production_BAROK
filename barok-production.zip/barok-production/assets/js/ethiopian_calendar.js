/**
 * BAROK PRODUCTION - Client-Side Ethiopian Calendar Engine
 * Provides JDN-based bidirectional Gregorian <-> Ethiopian date conversions.
 */

(function (window) {
    'use strict';

    const ETHIOPIAN_EPOCH_JDN = 1723856;

    const MONTHS_AMHARIC = [
        '',
        'መስከረም',
        'ጥቅምት',
        'ኅዳር',
        'ታኅሣሥ',
        'ጥር',
        'የካቲት',
        'መጋቢት',
        'ሚያዝያ',
        'ግንቦት',
        'ሰኔ',
        'ሐምሌ',
        'ነሐሴ',
        'ጳጉሜ'
    ];

    const MONTHS_ENGLISH = [
        '',
        'Meskerem',
        'Tikimt',
        'Hidar',
        'Tahsas',
        'Tir',
        'Yekatit',
        'Megabit',
        'Miyazya',
        'Ginbot',
        'Sene',
        'Hamle',
        'Nehase',
        'Pagume'
    ];

    function gregorianToJdn(year, month, day) {
        if (month <= 2) {
            year -= 1;
            month += 12;
        }
        const a = Math.floor(year / 100);
        const b = 2 - a + Math.floor(a / 4);
        return Math.floor(365.25 * (year + 4716)) + Math.floor(30.6001 * (month + 1)) + day + b - 1524;
    }

    function jdnToGregorian(jdn) {
        const j = jdn + 1402;
        const k = Math.floor((j - 1) / 1461);
        const l = j - 1461 * k;
        const n = Math.floor((l - 1) / 365) - Math.floor(l / 1461);
        const i = l - 365 * n + 30;
        const j2 = Math.floor((80 * i) / 2447);
        const day = i - Math.floor((2447 * j2) / 80);
        const i2 = Math.floor(j2 / 11);
        const month = j2 + 2 - 12 * i2;
        const year = 4 * k + n + i2 - 4716;

        const mm = String(month).padStart(2, '0');
        const dd = String(day).padStart(2, '0');
        return {
            year: year,
            month: month,
            day: day,
            formatted: `${year}-${mm}-${dd}`
        };
    }

    function jdnToEthiopian(jdn) {
        const r = (jdn - ETHIOPIAN_EPOCH_JDN) % 1461;
        const n = (r % 365) + 365 * Math.floor(r / 1460);
        const year = 4 * Math.floor((jdn - ETHIOPIAN_EPOCH_JDN) / 1461) + Math.floor(r / 365) - Math.floor(r / 1460);
        const month = Math.floor(n / 30) + 1;
        const day = (n % 30) + 1;

        const monthAm = MONTHS_AMHARIC[month] || '';
        const monthEn = MONTHS_ENGLISH[month] || '';

        return {
            year: year,
            month: month,
            day: day,
            month_name_am: monthAm,
            month_name_en: monthEn,
            formatted_am: `${monthAm} ${day} ቀን ${year} ዓ.ም.`,
            formatted_en: `${monthEn} ${day}, ${year} E.C.`
        };
    }

    function ethiopianToJdn(year, month, day) {
        return (ETHIOPIAN_EPOCH_JDN + 365) + 365 * (year - 1) + Math.floor(year / 4) + 30 * (month - 1) + day - 366;
    }

    const EthiopicDate = {
        MONTHS_AMHARIC: MONTHS_AMHARIC,
        MONTHS_ENGLISH: MONTHS_ENGLISH,

        fromGregorian: function (dateStr) {
            if (!dateStr) return null;
            const parts = dateStr.split('-');
            if (parts.length !== 3) return null;
            const y = parseInt(parts[0], 10);
            const m = parseInt(parts[1], 10);
            const d = parseInt(parts[2], 10);

            const jdn = gregorianToJdn(y, m, d);
            return jdnToEthiopian(jdn);
        },

        toGregorian: function (ethYear, ethMonth, ethDay) {
            const jdn = ethiopianToJdn(parseInt(ethYear, 10), parseInt(ethMonth, 10), parseInt(ethDay, 10));
            return jdnToGregorian(jdn);
        },

        getDaysInMonth: function (ethYear, ethMonth) {
            ethMonth = parseInt(ethMonth, 10);
            ethYear = parseInt(ethYear, 10);
            if (ethMonth < 13) return 30;
            // Pagume: 6 in leap year (every 4th year where ethYear % 4 === 3)
            return (ethYear % 4 === 3) ? 6 : 5;
        }
    };

    window.EthiopicDate = EthiopicDate;

})(window);
