/**
 * BAROK PRODUCTION - Main Client Scripts
 */

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initPortfolioFilters();
    initServiceFilters();
    initLightbox();
    initContactForm();
});

/* Toast Notification Utility */
window.showToast = function(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <span class="toast-icon">${type === 'success' ? '✓' : '⚠️'}</span>
        <span class="toast-text">${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
};

/* Mobile Navigation Toggle */
function initNavigation() {
    const toggleBtn = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');

    if (toggleBtn && navLinks) {
        toggleBtn.addEventListener('click', () => {
            navLinks.classList.toggle('show');
            const isOpen = navLinks.classList.contains('show');
            toggleBtn.innerHTML = isOpen ? '✕' : '☰';
        });

        // Close when clicking nav link
        navLinks.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                navLinks.classList.remove('show');
                if (toggleBtn) toggleBtn.innerHTML = '☰';
            });
        });
    }

    // Scroll Navbar blur accent
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.style.background = 'rgba(10, 12, 18, 0.95)';
            navbar.style.borderColor = 'rgba(255, 183, 3, 0.2)';
        } else {
            navbar.style.background = 'rgba(14, 17, 26, 0.8)';
            navbar.style.borderColor = 'var(--glass-border)';
        }
    });
}

/* Portfolio Filter Tabs */
function initPortfolioFilters() {
    const filterButtons = document.querySelectorAll('.portfolio-filter-btn');
    const portfolioCards = document.querySelectorAll('.portfolio-card');

    if (!filterButtons.length) return;

    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filter = btn.getAttribute('data-filter');

            portfolioCards.forEach(card => {
                const category = card.getAttribute('data-category');
                if (filter === 'all' || category === filter) {
                    card.style.display = 'block';
                    card.style.opacity = '0';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transition = 'opacity 0.3s ease';
                    }, 30);
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
}

/* Service Filter Tabs */
function initServiceFilters() {
    const filterButtons = document.querySelectorAll('.service-filter-btn');
    const serviceCards = document.querySelectorAll('.service-card');

    if (!filterButtons.length) return;

    filterButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            filterButtons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filter = btn.getAttribute('data-service-type');

            serviceCards.forEach(card => {
                const serviceType = card.getAttribute('data-service-type');
                if (filter === 'all' || serviceType === filter) {
                    card.style.display = 'flex';
                    card.style.opacity = '0';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transition = 'opacity 0.3s ease';
                    }, 30);
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
}

/* Lightbox Modal */
function initLightbox() {
    const lightbox = document.getElementById('portfolioLightbox');
    if (!lightbox) return;

    const closeBtn = lightbox.querySelector('.lightbox-close-btn');
    const container = lightbox.querySelector('.lightbox-media-container');
    const titleEl = lightbox.querySelector('.lightbox-title');
    const descEl = lightbox.querySelector('.lightbox-desc');
    const clientEl = lightbox.querySelector('.lightbox-client');

    const openLightbox = (title, type, mediaUrl, desc, client) => {
        container.innerHTML = '';

        if (type === 'video') {
            const iframe = document.createElement('iframe');
            iframe.src = mediaUrl;
            iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
            iframe.allowFullscreen = true;
            container.appendChild(iframe);
        } else {
            const img = document.createElement('img');
            img.src = mediaUrl;
            img.alt = title;
            container.appendChild(img);
        }

        if (titleEl) titleEl.textContent = title;
        if (descEl) descEl.textContent = desc || '';
        if (clientEl) clientEl.textContent = client ? `Client: ${client}` : '';

        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
    };

    const closeLightbox = () => {
        lightbox.classList.remove('active');
        container.innerHTML = '';
        document.body.style.overflow = 'auto';
    };

    document.querySelectorAll('.portfolio-card').forEach(card => {
        card.addEventListener('click', () => {
            const title = card.getAttribute('data-title');
            const type = card.getAttribute('data-type');
            const mediaUrl = card.getAttribute('data-media');
            const desc = card.getAttribute('data-desc');
            const client = card.getAttribute('data-client');
            openLightbox(title, type, mediaUrl, desc, client);
        });
    });

    if (closeBtn) closeBtn.addEventListener('click', closeLightbox);
    lightbox.addEventListener('click', (e) => {
        if (e.target === lightbox) closeLightbox();
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && lightbox.classList.contains('active')) {
            closeLightbox();
        }
    });
}

/* Contact Form AJAX */
function initContactForm() {
    const contactForm = document.getElementById('contactForm');
    if (!contactForm) return;

    contactForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;

        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span>Sending Inquiry...</span>';

        const formData = new FormData(contactForm);

        try {
            const response = await fetch('api/contact.php', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            if (result.success) {
                showToast(result.message || 'Thank you! Your message has been received.', 'success');
                contactForm.reset();
            } else {
                showToast(result.message || 'Could not send message. Please try again.', 'error');
            }
        } catch (error) {
            showToast('A network error occurred. Please try again.', 'error');
        } finally {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    });
}
