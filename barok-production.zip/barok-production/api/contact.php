<?php
/**
 * BAROK PRODUCTION - API: Handle General Contact Form Inquiries
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

$name    = sanitize($_POST['name'] ?? '');
$email   = sanitize($_POST['email'] ?? '');
$subject = sanitize($_POST['subject'] ?? 'New General Inquiry');
$message = sanitize($_POST['message'] ?? '');

if (empty($name) || empty($email) || empty($message)) {
    jsonResponse(['success' => false, 'message' => 'Please fill in all required fields.'], 422);
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    jsonResponse(['success' => false, 'message' => 'Please provide a valid email address.'], 422);
}

try {
    $pdo = Database::getConnection();
    $stmt = $pdo->prepare("INSERT INTO inquiries (name, email, subject, message) VALUES (:name, :email, :subject, :msg)");
    $stmt->execute([
        ':name'    => $name,
        ':email'   => $email,
        ':subject' => $subject,
        ':msg'     => $message
    ]);

    jsonResponse([
        'success' => true,
        'message' => 'Thank you! Your message has been sent to the BAROK PRODUCTION team.'
    ]);
} catch (Throwable $e) {
    jsonResponse([
        'success' => false,
        'message' => 'Unable to save inquiry. Please try again later.',
        'error'   => $e->getMessage()
    ], 500);
}
