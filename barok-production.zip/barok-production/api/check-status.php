<?php
/**
 * BAROK PRODUCTION - API: Check Booking Status by Reference Code
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

$ref = strtoupper(trim(sanitize($_GET['ref'] ?? '')));

if (empty($ref)) {
    jsonResponse(['success' => false, 'message' => 'Please provide a booking reference code.'], 400);
}

try {
    $pdo = Database::getConnection();

    $stmt = $pdo->prepare("
        SELECT 
            b.id,
            b.reference_code,
            b.client_name,
            b.booking_date,
            b.booking_time,
            b.shoot_location,
            b.add_ons,
            b.total_price,
            b.status,
            b.admin_notes,
            b.created_at,
            s.title AS service_title,
            s.category AS service_category,
            s.duration_hours
        FROM bookings b
        JOIN services s ON b.service_id = s.id
        WHERE b.reference_code = :ref
        LIMIT 1
    ");

    $stmt->execute([':ref' => $ref]);
    $booking = $stmt->fetch();

    if (!$booking) {
        jsonResponse(['success' => false, 'message' => 'No booking reservation found matching that reference code.'], 404);
    }

    $booking['add_ons'] = json_decode($booking['add_ons'] ?? '[]', true) ?: [];
    $booking['formatted_total'] = formatPrice((float)$booking['total_price']);

    jsonResponse([
        'success' => true,
        'data'    => $booking
    ]);
} catch (Throwable $e) {
    jsonResponse([
        'success' => false,
        'message' => 'Unable to check booking status.',
        'error'   => $e->getMessage()
    ], 500);
}
