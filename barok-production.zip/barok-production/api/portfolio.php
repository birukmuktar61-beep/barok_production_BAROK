<?php
/**
 * BAROK PRODUCTION - API: Get Portfolio Showcase Items
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

try {
    $pdo = Database::getConnection();

    $category = sanitize($_GET['category'] ?? '');

    if (!empty($category) && $category !== 'all') {
        $stmt = $pdo->prepare("SELECT id, title, category, client_name, project_year, media_type, thumbnail_url, media_url, description, is_featured FROM portfolio WHERE category = :category ORDER BY sort_order ASC, id DESC");
        $stmt->execute([':category' => $category]);
    } else {
        $stmt = $pdo->prepare("SELECT id, title, category, client_name, project_year, media_type, thumbnail_url, media_url, description, is_featured FROM portfolio ORDER BY sort_order ASC, id DESC");
        $stmt->execute();
    }

    $items = $stmt->fetchAll();

    jsonResponse([
        'success' => true,
        'count'   => count($items),
        'data'    => $items
    ]);
} catch (Throwable $e) {
    jsonResponse([
        'success' => false,
        'message' => 'Unable to fetch portfolio projects.',
        'error'   => $e->getMessage()
    ], 500);
}
