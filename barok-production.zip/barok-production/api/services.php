<?php
/**
 * BAROK PRODUCTION - API: Get Active Services & Pricing
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

try {
    $pdo = Database::getConnection();
    $typeFilter = sanitize($_GET['type'] ?? '');
    if (!empty($typeFilter) && in_array($typeFilter, ['photo', 'video', 'both'], true)) {
        $stmt = $pdo->prepare("SELECT id, title, service_type, category, price, duration_hours, short_desc, features, is_featured FROM services WHERE is_active = 1 AND service_type = :type ORDER BY price ASC");
        $stmt->execute([':type' => $typeFilter]);
    } else {
        $stmt = $pdo->prepare("SELECT id, title, service_type, category, price, duration_hours, short_desc, features, is_featured FROM services WHERE is_active = 1 ORDER BY service_type ASC, price ASC");
        $stmt->execute();
    }
    $services = $stmt->fetchAll();

    foreach ($services as &$service) {
        $service['price'] = (float)$service['price'];
        $service['formatted_price'] = formatPrice($service['price']);
        $service['features'] = json_decode($service['features'] ?? '[]', true) ?: [];
    }

    jsonResponse([
        'success' => true,
        'count'   => count($services),
        'data'    => $services
    ]);
} catch (Throwable $e) {
    jsonResponse([
        'success' => false,
        'message' => 'Unable to fetch services.',
        'error'   => $e->getMessage()
    ], 500);
}
