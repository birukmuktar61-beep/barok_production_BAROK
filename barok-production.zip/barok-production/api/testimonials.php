<?php
/**
 * BAROK PRODUCTION - API: Testimonials Submission & Approved List
 *
 * Public clients can submit reviews (which enter moderation queue as is_approved = 0).
 * Only approved reviews (is_approved = 1) are returned for public display.
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

$pdo = Database::getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        $input = $_POST;
    }

    $clientName  = sanitize($input['client_name'] ?? '');
    $clientRole  = sanitize($input['client_role'] ?? '');
    $projectType = sanitize($input['project_type'] ?? '');
    $reviewText  = sanitize($input['review_text'] ?? '');
    $rating      = (int)($input['rating'] ?? 5);

    // Validation
    if (empty($clientName)) {
        jsonResponse(['success' => false, 'message' => 'Please provide your name.'], 422);
    }
    if (empty($reviewText) || strlen($reviewText) < 10) {
        jsonResponse(['success' => false, 'message' => 'Please write at least a few words (10+ characters) for your review.'], 422);
    }
    if ($rating < 1 || $rating > 5) {
        $rating = 5;
    }

    try {
        $stmt = $pdo->prepare("
            INSERT INTO testimonials (client_name, client_role, project_type, rating, review_text, is_approved)
            VALUES (:name, :role, :project_type, :rating, :text, 0)
        ");
        $stmt->execute([
            ':name'         => $clientName,
            ':role'         => $clientRole ?: null,
            ':project_type' => $projectType ?: null,
            ':rating'       => $rating,
            ':text'         => $reviewText
        ]);

        $newId = (int)$pdo->lastInsertId();

        $lang = getCurrentLang();
        $successMsg = ($lang === 'am')
            ? 'አስተያየትዎ በተሳካ ሁኔታ ተልኳል፤ በአስተዳዳሪው ከተገመገመ እና ከጸደቀ በኋላ በድረ-ገጻችን ላይ ይታያል። እናመሰግናለን!'
            : 'Thank you! Your review has been submitted for moderation and will appear on our showcase once approved by the studio.';

        jsonResponse([
            'success'        => true,
            'testimonial_id' => $newId,
            'is_approved'    => false,
            'message'        => $successMsg
        ], 201);
    } catch (Throwable $e) {
        jsonResponse([
            'success' => false,
            'message' => 'Failed to save your review. Please try again later.',
            'error'   => $e->getMessage()
        ], 500);
    }
}

// GET: Return approved reviews
try {
    $stmt = $pdo->query("SELECT id, client_name, client_role, project_type, rating, review_text, created_at FROM testimonials WHERE is_approved = 1 ORDER BY id DESC");
    $testimonials = $stmt->fetchAll();

    jsonResponse([
        'success' => true,
        'count'   => count($testimonials),
        'data'    => $testimonials
    ]);
} catch (Throwable $e) {
    jsonResponse([
        'success' => false,
        'message' => 'Unable to fetch reviews.',
        'error'   => $e->getMessage()
    ], 500);
}
