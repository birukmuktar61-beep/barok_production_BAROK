<?php
/**
 * BAROK PRODUCTION - API: Process Client Booking
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['success' => false, 'message' => 'Method not allowed.'], 405);
}

// Support both JSON payload and regular POST form data
$raw = file_get_contents('php://input');
$payload = json_decode($raw, true);

if (!is_array($payload)) {
    $payload = $_POST;
}

$serviceId    = isset($payload['service_id']) ? (int)$payload['service_id'] : 0;
$bookingDate  = sanitize($payload['booking_date'] ?? '');
$bookingTime  = sanitize($payload['booking_time'] ?? '');
$shootLocation = sanitize($payload['shoot_location'] ?? '');
$projectNotes = sanitize($payload['project_notes'] ?? '');
$addOnsRaw    = $payload['add_ons'] ?? '[]';
$clientName   = sanitize($payload['client_name'] ?? '');
$clientEmail  = sanitize($payload['client_email'] ?? '');
$clientPhone  = sanitize($payload['client_phone'] ?? '');

// Validation
$errors = [];
if ($serviceId <= 0) {
    $errors[] = 'A valid production service package must be selected.';
}
if (empty($bookingDate) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $bookingDate)) {
    $errors[] = 'A valid booking date (YYYY-MM-DD) is required.';
}
if (empty($shootLocation)) {
    $errors[] = 'Shoot location or studio address is required.';
}
if (empty($clientName) || strlen($clientName) < 2) {
    $errors[] = 'Your full name is required.';
}
if (empty($clientEmail) || !filter_var($clientEmail, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'A valid contact email is required.';
}
if (empty($clientPhone) || strlen($clientPhone) < 7) {
    $errors[] = 'A valid contact telephone/mobile number is required.';
}

if (!empty($errors)) {
    jsonResponse(['success' => false, 'message' => implode(' ', $errors)], 422);
}

try {
    $pdo = Database::getConnection();

    // Verify service exists and fetch price
    $stmt = $pdo->prepare("SELECT id, title, price FROM services WHERE id = :id AND is_active = 1");
    $stmt->execute([':id' => $serviceId]);
    $service = $stmt->fetch();

    if (!$service) {
        jsonResponse(['success' => false, 'message' => 'The selected package was not found.'], 404);
    }

    $basePrice = (float)$service['price'];
    $totalPrice = $basePrice;

    // Calculate add-on cost
    $parsedAddons = is_string($addOnsRaw) ? json_decode($addOnsRaw, true) : $addOnsRaw;
    if (is_array($parsedAddons)) {
        foreach ($parsedAddons as $addon) {
            if (isset($addon['price'])) {
                $totalPrice += (float)$addon['price'];
            }
        }
    }

    // Generate unique reference code
    $referenceCode = '';
    do {
        $referenceCode = generateBookingReference();
        $chk = $pdo->prepare("SELECT 1 FROM bookings WHERE reference_code = :ref");
        $chk->execute([':ref' => $referenceCode]);
    } while ($chk->fetch());

    // Insert booking
    $insert = $pdo->prepare("
        INSERT INTO bookings (
            reference_code,
            client_name,
            client_email,
            client_phone,
            service_id,
            booking_date,
            booking_time,
            shoot_location,
            project_notes,
            add_ons,
            total_price,
            status
        ) VALUES (
            :ref,
            :name,
            :email,
            :phone,
            :service_id,
            :booking_date,
            :booking_time,
            :shoot_location,
            :notes,
            :add_ons,
            :total_price,
            'pending'
        )
    ");

    $insert->execute([
        ':ref'           => $referenceCode,
        ':name'          => $clientName,
        ':email'         => $clientEmail,
        ':phone'         => $clientPhone,
        ':service_id'    => $serviceId,
        ':booking_date'  => $bookingDate,
        ':booking_time'  => $bookingTime ?: '10:00 AM - 02:00 PM',
        ':shoot_location'=> $shootLocation,
        ':notes'         => $projectNotes,
        ':add_ons'       => is_string($addOnsRaw) ? $addOnsRaw : json_encode($parsedAddons),
        ':total_price'   => $totalPrice
    ]);

    $bookingId = (int)$pdo->lastInsertId();

    jsonResponse([
        'success' => true,
        'message' => 'Your booking has been reserved successfully!',
        'data'    => [
            'booking_id'     => $bookingId,
            'reference_code' => $referenceCode,
            'service_title'  => $service['title'],
            'booking_date'   => $bookingDate,
            'booking_time'   => $bookingTime,
            'total_price'    => $totalPrice,
            'formatted_total'=> formatPrice($totalPrice)
        ]
    ], 201);
} catch (Throwable $e) {
    jsonResponse([
        'success' => false,
        'message' => 'An error occurred while saving your booking reservation.',
        'error'   => $e->getMessage()
    ], 500);
}
